const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "mysql",
    user: "root",
    password: "",
    database: "login_db"
});

db.connect(err => {
    if (err) {
        console.log("erro:", err);
    } else {
        console.log("mysql conectado");
    }
});

module.exports = db;