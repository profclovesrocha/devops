const express = require("express");
const db = require("./db");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// cadastro
app.post("/cadastro", (req, res) => {
    const { user, pass } = req.body;

    db.query(
        "INSERT INTO users (username, password) VALUES (?, ?)",
        [user, pass],
        () => {
            res.send("ok");
        }
    );
});

// login
app.post("/login", (req, res) => {
    const { user, pass } = req.body;

    db.query(
        "SELECT * FROM users WHERE username = ? AND password = ?",
        [user, pass],
        (err, result) => {
            if (result.length > 0) {
                res.send("success");
            } else {
                res.send("error");
            }
        }
    );
});

app.listen(3000, () => {
    console.log("http://localhost:3000");
});