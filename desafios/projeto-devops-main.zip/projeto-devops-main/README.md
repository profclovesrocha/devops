# 🔐 Brute Force Simulator

### Interface inspirada no League of Legends

![status](https://img.shields.io/badge/status-em%20desenvolvimento-yellow)
![license](https://img.shields.io/badge/license-MIT-blue)
![stack](https://img.shields.io/badge/stack-HTML%20%7C%20CSS%20%7C%20JS%20%7C%20Node%2FPHP-green)

---

## 📖 Sobre o Projeto 
— Matheus

O **Brute Force Simulator** é uma aplicação web desenvolvida com o objetivo de **simular ataques de força bruta em sistemas de autenticação**, utilizando uma interface moderna inspirada no **League of Legends**.

O projeto foi criado para fins **educacionais**, permitindo visualizar na prática como ataques automatizados funcionam e como sistemas mal protegidos podem ser vulneráveis.

---

## ✨ Features

* 🎮 Interface estilizada (inspirada no LoL)
* 🔐 Sistema de login funcional
* 💣 Simulação de ataque de força bruta
* 📊 Feedback em tempo real das tentativas
* 🧠 Integração com banco de dados (MySQL)
* ⚙️ Suporte a backend em:

  * Node.js
  * PHP (XAMPP)

---

## 🖼️ Preview

> ![Preview do Projeto](public/imagens/preview.png)

---

## 🧠 Conceitos Aplicados

* Segurança da Informação
* Autenticação de usuários
* Ataques de força bruta
* Estrutura cliente-servidor
* Manipulação de DOM
* Requisições HTTP
* Integração com banco de dados

---

## 🏗️ Arquitetura

```bash
ProjetoDevOps/
│
├── public/              # Front-end
│   ├── index.html
│   ├── cadastro.html
│   ├── style.css
│   ├── script.js        # Scripts do front-end (requisições, eventos, UI)
│
├── imagens/             # Assets visuais
│
├── backend/             # Lógica do servidor
│   ├── server.js        # Servidor principal (API)
│   ├── bruteForce.js    # Simulação de ataque de força bruta
│   └── db.js            # Conexão e configuração do banco de dados
│
├── database/
│   └── schema.sql       # Estrutura do banco
│
└── README.md
```

---

## 🚀 Getting Started

### 📥 Clone o repositório

```bash
git clone https://github.com/losthotel/projeto-devops.git
cd projeto-devops-main
```

---

## ⚙️ Configuração

### 🔹 XAMPP (PHP + MySQL)

1. Instale o XAMPP v3.3.0

2. Inicie:

   * Apache
   * MySQL

3. Mova o projeto para:

```bash
C:\xampp\htdocs\
```

4. Acesse:

```bash
http://localhost/phpmyadmin
```

5. Crie o banco:

```sql
CREATE DATABASE login_db;
```

6. Importe o arquivo:

```bash
login_db.sql
```

---

## ▶️ Executando o Projeto

Abra no navegador:

```bash
http://localhost:3000
```

---

## 💣 Simulação de Ataque

O sistema executa tentativas automáticas utilizando uma **wordlist de senhas comuns**.

### Exemplo de lógica:

```javascript
const usuario = "Teste";
const caracteres = "abc123";
const maxLength = 6;

let encontrado = false;
let tentativas = 0;

function embaralhar(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}
```

---

## 🔐 Segurança (Melhorias Futuras)

* [ ] Sistema de bloqueio por tentativas
* [x] CAPTCHA
* [ ] Logs de acesso
* [ ] Detecção de comportamento suspeito

---

## ⚠️ Aviso Legal

Este projeto foi desenvolvido exclusivamente para fins:

* Educacionais
* Acadêmicos
* Demonstrações controladas

🚫 **Não utilize este sistema para ataques reais ou atividades ilegais.**

---

## 📌 Roadmap

* [ ] Melhorar UI estilo League of Legends
* [ ] Adicionar dashboard de ataques
* [ ] Gráfico em tempo real de tentativas
* [x] Sistema de usuários mais robusto

---


---

# 🏆 Desafios Desenvolvidos

## 🚀 Desafio 1 — Automação de Deploy e Integração Contínua (CI/CD) 
— Natalia

O objetivo foi criar uma esteira de Automação de Deploy e Integração Contínua (CI/CD) utilizando GitHub Actions. A arquitetura foi projetada para garantir que qualquer alteração no código seja testada, empacotada em um container estável e disponibilizada para produção de forma 100% automática, rápida e segura.

Toda a lógica foi centralizada na branch **main** no diretório **.github/workflows/** por meio de dois arquivos principais:

- **ci.yml**
- **cd.yml**

### ✅ Resultados

- Pipeline CI/CD automatizado
- Validação automática de alterações
- Empacotamento padronizado da aplicação
- Deploy automatizado
- Redução de falhas manuais

---

## 🐳 Desafio 2 — Docker, Monitoramento e Dashboard DevOps 
— Vitor Hugo

Durante o desenvolvimento do projeto DevOps, fui responsável pela implementação e organização do ambiente da aplicação utilizando tecnologias modernas de infraestrutura e monitoramento.

### Principais atividades

- Integração completa do Docker ao projeto
- Configuração do Dockerfile
- Configuração do docker-compose.yml
- Containerização da aplicação e banco MySQL
- Ajustes de conectividade entre serviços

### Dashboard DevOps / DCIM

Desenvolvido utilizando:

- Python
- Streamlit

Funcionalidades:

- Monitoramento de CPU
- Monitoramento de Memória RAM
- Monitoramento de Disco
- Status do Sistema
- Gráficos dinâmicos
- Atualização automática
- Indicadores de desempenho
- Status online/offline de serviços simulados

### Integração de Dados

- CSV
- Excel
- SQLite

### Versionamento

- Organização de branches
- Fluxo Git estruturado
- Separação de funcionalidades
- Melhor gerenciamento do repositório

### ✅ Resultados

- Ambiente totalmente containerizado
- Dashboard funcional em tempo real
- Integração com múltiplas fontes de dados
- Estrutura Git organizada

---

## ☸️ Desafio 3 — Kubernetes e Helm para Deploy Multiambiente 
— Lindalva

Implementação de uma solução de orquestração de containers utilizando Kubernetes e Helm com foco em deploy multiambiente.

### Estrutura do Chart

```bash
meu-app/
├── Chart.yaml
├── values.yaml
├── values-dev.yaml
├── values-prod.yaml
├── .helmignore
└── templates/
    ├── deployment.yaml
    └── service.yaml
```

### Ambiente DEV

- 1 réplica
- nginx:alpine
- 64Mi RAM
- 50m CPU

### Ambiente PROD

- 3 réplicas
- nginx:latest
- 128Mi RAM
- 100m CPU
- Limites de 256Mi RAM e 200m CPU

### Resultados Alcançados

| Item | Status |
|--------|--------|
| Helm instalado e configurado | ✅ |
| Cluster Kubernetes funcionando | ✅ |
| Chart criado com templates | ✅ |
| Deploy DEV com 1 réplica | ✅ |
| Deploy PROD com 3 réplicas | ✅ |
| Port-forward funcionando | ✅ |
| Aplicação acessível via navegador | ✅ |
| Rollback executado com sucesso | ✅ |
| Logs em tempo real | ✅ |

### 🧠 Principais Aprendizados

- Uso de Helm para ambientes distintos
- Parametrização com values files
- Rollback de versões
- Isolamento por namespaces
- Boas práticas de Infraestrutura como Código

### ✅ Conclusão

Solução funcional, documentada e alinhada às boas práticas modernas de Kubernetes, Helm e Infraestrutura como Código.

---

## 📄 Licença

Este projeto está sob a licença MIT.

---

## 👨‍💻 Autores

| Nome           | Atribuição no Projeto         |
|----------------|-------------------------------|
| **Matheus**    | Confecção do Projeto e corretor dos desafios
| **Alysson**    | Responsável pelo Teste de Software
| **Natalia**    | Responsável pela confecção do Desafio 1 e 4
| **Natthan**    | Responsável pelo Teste de Software         
| **Lindalva**   | Responsável pela confecção do Desafio 3
| **Vitor Hugo** | Responsável pela confecção do Desafio 2 e 5
| **Jonathan**   | Responsável pela confecção do Slide
| **Sabrina**    | Responsável pela confecção do Desafio 5
