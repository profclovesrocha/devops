"""Regras de monitoramento: transformam o que foi coletado em incidentes.

Cada regra tem nome, severidade e limiar explícitos; a página Incidentes
mostra a lista para quem quiser conferir (ou citar no relatório).
"""
from __future__ import annotations

import time
from collections import defaultdict, deque

from .coleta import MOTIVOS_FALHA

# Documentação das regras (exibida no painel).
CATALOGO = [
    ("SITE_FORA_DO_AR", "CRITICA", "Site ou API sem responder 200 em 3 checagens seguidas (por fora, pelo domínio)"),
    ("SITE_LENTO", "MEDIA", "Resposta acima do limite de latência em 5 checagens seguidas"),
    ("CERTIFICADO_EXPIRANDO", "MEDIA", "Certificado HTTPS vence em poucos dias (crítico com menos de 3)"),
    ("CERTIFICADO_NAO_EMITIDO", "ALTA", "cert-manager não consegue emitir o certificado há 15 minutos"),
    ("POD_COM_FALHA", "CRITICA", "Pod em CrashLoopBackOff, erro de imagem ou de configuração"),
    ("POD_REINICIANDO", "ALTA", "Pod reiniciou 3 vezes em 15 minutos"),
    ("POD_NAO_PRONTO", "MEDIA", "Pod rodando mas sem passar na prontidão há 5 minutos"),
    ("POD_PENDENTE", "MEDIA", "Pod sem conseguir ser agendado há 5 minutos"),
    ("NO_INDISPONIVEL", "CRITICA", "Nó do Kubernetes fora do estado Ready"),
    ("NO_SOB_PRESSAO", "ALTA", "Nó com pressão de memória, disco ou processos"),
    ("CPU_ALTA", "MEDIA", "Uso de CPU do servidor acima do limite por 5 minutos"),
    ("MEMORIA_ALTA", "ALTA", "Uso de memória do servidor acima do limite por 5 minutos"),
    ("DISCO_CHEIO", "ALTA", "Disco do servidor acima do limite (crítico acima de 90%)"),
    ("BANCO_INDISPONIVEL", "CRITICA", "A API informa que o MySQL não responde"),
    ("ROTACAO_JWT_ATRASADA", "ALTA", "Chave que assina os tokens passou de 1,5x o intervalo de rotação"),
    ("METRICAS_INDISPONIVEIS", "MEDIA", "Sentinela não consegue ler as métricas da API há 10 minutos"),
    ("ERROS_5XX", "ALTA", "Muitas respostas 5xx da API em 5 minutos"),
    ("ERROS_APLICACAO", "ALTA", "5 ou mais erros internos da API em 5 minutos"),
    ("ALERTA_CRITICO_APLICACAO", "CRITICA", "A aplicação registrou porta forçada ou violação de leitor"),
    ("PICO_ALERTAS", "ALTA", "Muitos alertas de segurança da aplicação em 10 minutos"),
    ("LOGIN_FORCA_BRUTA", "ALTA", "Várias senhas erradas do mesmo IP no painel em 5 minutos"),
    ("CONTA_BLOQUEADA", "ALTA", "Conta de operador bloqueada por senhas erradas"),
    ("SSH_FORCA_BRUTA", "ALTA", "Várias falhas de login SSH do mesmo IP em 10 minutos"),
    ("FALTA_DE_MEMORIA", "ALTA", "O kernel matou um processo por falta de memória (OOM)"),
    ("SYSLOG_SILENCIOSO", "MEDIA", "Um ambiente parou de mandar syslog"),
    ("AGENTE_SEM_SINAL", "MEDIA", "O agente do servidor parou de mandar métricas"),
    ("SENTINELA_SEM_KUBERNETES", "MEDIA", "O Sentinela não consegue ler a API do Kubernetes"),
]


class Regras:
    def __init__(self, cfg, store, incidentes):
        self.cfg = cfg
        self.store = store
        self.inc = incidentes
        self.lim = cfg.limiares
        self._reinicios: dict[str, int] = {}
        self._reinicios_ts: dict[str, deque] = defaultdict(lambda: deque(maxlen=20))
        self._sem_metricas_desde: dict[str, float] = {}

    def _amb_nome(self, amb_id: str) -> str:
        for a in self.cfg.ambientes:
            if a.id == amb_id:
                return a.nome
        return amb_id

    def _namespaces_criticos(self) -> set[str]:
        return {a.namespace for a in self.cfg.ambientes} | {"sentinela"}

    # ------------------------------------------------------------ checagens --
    def checagem(self, amb, alvo: str, nome_alvo: str, r: dict, falhas_seguidas: int, lentas_seguidas: int,
                 agora: float) -> None:
        sev = "CRITICA" if amb.app_env == "production" else "ALTA"
        self.inc.condicao(
            "SITE_FORA_DO_AR", f"site:{alvo}", falhas_seguidas >= 3, sev,
            f"{nome_alvo} fora do ar ({amb.nome})",
            f"{r['url']} não responde corretamente: {r.get('erro') or 'sem resposta'}. "
            f"{falhas_seguidas} checagens seguidas com falha.",
            r["url"], agora=agora, resolucao="Voltou a responder")
        self.inc.condicao(
            "SITE_LENTO", f"lento:{alvo}", lentas_seguidas >= 5, "MEDIA",
            f"{nome_alvo} lento ({amb.nome})",
            f"Última resposta em {r.get('latencia_ms')} ms (limite: {self.lim.latencia_ms} ms).",
            r["url"], agora=agora, resolucao="Tempo de resposta normalizado")

    def tls(self, host: str, r: dict, agora: float) -> None:
        if not r.get("ok"):
            return  # a falha aparece na checagem do site, com a causa
        dias = r.get("dias") or 0
        ativa = dias < self.lim.certificado_dias
        self.inc.condicao(
            "CERTIFICADO_EXPIRANDO", f"tls:{host}", ativa, "CRITICA" if dias < 3 else "MEDIA",
            f"Certificado de {host} vence em {dias:.0f} dias",
            f"Emitido por {r.get('emissor')}. O cert-manager renova sozinho cerca de 30 dias antes; se não renovou, "
            "confira `kubectl get certificate -A`.", host, agora=agora, resolucao="Certificado renovado")

    # ----------------------------------------------------------- kubernetes --
    def kube(self, retrato: dict, agora: float) -> None:
        criticos = self._namespaces_criticos()
        atuais: dict[str, set] = defaultdict(set)
        for p in retrato["pods"]:
            if p["fase"] == "Succeeded":
                continue
            ident = f"{p['namespace']}/{p['dono']}"
            local = f"{p['namespace']}/{p['nome']}"
            # Falha de container (CrashLoop, imagem, configuração).
            if p["motivo"] in MOTIVOS_FALHA or p["fase"] == "Failed":
                chave = f"pod:{ident}"
                atuais["POD_COM_FALHA"].add(chave)
                extra = " A última execução terminou por falta de memória (OOMKilled)." if p["ultimo_termino"] == "OOMKilled" else ""
                self.inc.condicao(
                    "POD_COM_FALHA", chave, True, "CRITICA" if p["namespace"] in criticos else "ALTA",
                    f"Pod {p['dono']} com falha ({p['motivo'] or p['fase']})",
                    f"{local} está em {p['motivo'] or p['fase']}.{extra} "
                    f"Veja: kubectl -n {p['namespace']} describe pod {p['nome']}", local, agora=agora,
                    resolucao="Pod recuperado")
            # Reinícios.
            anterior = self._reinicios.get(p["uid"])
            self._reinicios[p["uid"]] = p["reinicios"]
            if anterior is not None and p["reinicios"] > anterior:
                for _ in range(p["reinicios"] - anterior):
                    self._reinicios_ts[ident].append(agora)
            recentes = [t for t in self._reinicios_ts.get(ident, ()) if agora - t <= 900]
            if len(recentes) >= 3:
                atuais["POD_REINICIANDO"].add(f"reinicio:{ident}")
                self.inc.condicao(
                    "POD_REINICIANDO", f"reinicio:{ident}", True, "ALTA",
                    f"{p['dono']} reiniciando ({len(recentes)} vezes em 15 min)",
                    f"Último motivo de término: {p['ultimo_termino'] or 'desconhecido'}. "
                    f"Logs: kubectl -n {p['namespace']} logs {p['nome']} --previous", local, agora=agora,
                    resolucao="Sem reinícios nos últimos 15 minutos")
            # Rodando sem ficar pronto / pendente.
            if p["fase"] == "Running" and not p["pronto"] and p["motivo"] not in MOTIVOS_FALHA:
                atuais["POD_NAO_PRONTO"].add(f"nao-pronto:{local}")
                self.inc.condicao("POD_NAO_PRONTO", f"nao-pronto:{local}", True, "MEDIA",
                                  f"Pod {p['nome']} não fica pronto",
                                  f"{p['prontos']}/{p['total']} containers prontos. A sonda de prontidão está falhando.",
                                  local, duracao=300, agora=agora, resolucao="Pod pronto")
            if p["fase"] == "Pending" and p["motivo"] not in MOTIVOS_FALHA:
                atuais["POD_PENDENTE"].add(f"pendente:{local}")
                self.inc.condicao("POD_PENDENTE", f"pendente:{local}", True, "MEDIA",
                                  f"Pod {p['nome']} pendente",
                                  "O Kubernetes não consegue agendar o pod (memória, cota ou volume).",
                                  local, duracao=300, agora=agora, resolucao="Pod agendado")
        for n in retrato["nos"]:
            chave = f"no:{n['nome']}"
            self.inc.condicao("NO_INDISPONIVEL", chave, not n["pronto"], "CRITICA", f"Nó {n['nome']} indisponível",
                              "O kubelet não está reportando Ready.", n["nome"], agora=agora, resolucao="Nó pronto")
            self.inc.condicao("NO_SOB_PRESSAO", f"pressao:{n['nome']}", bool(n["pressoes"]), "ALTA",
                              f"Nó {n['nome']} sob pressão", "Condições: " + ", ".join(n["pressoes"]), n["nome"],
                              agora=agora, resolucao="Pressão aliviada")
            if n.get("cpu_uso") is not None and n["cpu_nucleos"] and not self._tem_agente():
                pct = 100 * n["cpu_uso"] / n["cpu_nucleos"]
                self._cpu(n["nome"], pct, agora)
            if n.get("memoria_uso") is not None and n["memoria_bytes"] and not self._tem_agente():
                pct = 100 * n["memoria_uso"] / n["memoria_bytes"]
                self._memoria(n["nome"], pct, n["memoria_uso"], n["memoria_bytes"], agora)
        for c in retrato["certificados"]:
            chave = f"cert:{c['namespace']}/{c['nome']}"
            # Conta o tempo desde que o cert-manager marcou o problema (não desde que o Sentinela viu).
            ativa = c["pronto"] is False and (agora - (c.get("desde") or agora)) >= 900
            if c["pronto"] is False:
                atuais["CERTIFICADO_NAO_EMITIDO"].add(chave)
            self.inc.condicao("CERTIFICADO_NAO_EMITIDO", chave, ativa, "ALTA",
                              f"Certificado {c['nome']} não emitido",
                              f"{', '.join(c['dominios'])}: {c['mensagem'] or 'sem detalhes'}. "
                              f"Veja: kubectl -n {c['namespace']} describe certificate {c['nome']}",
                              c["namespace"], agora=agora, resolucao="Certificado emitido")
        # O que sumiu do cluster (pod apagado, por exemplo) deixa de ser problema.
        for regra in ("POD_COM_FALHA", "POD_REINICIANDO", "POD_NAO_PRONTO", "POD_PENDENTE", "CERTIFICADO_NAO_EMITIDO"):
            for chave in self.inc.chaves_ativas(regra) - atuais[regra]:
                self.inc.condicao(regra, chave, False, "INFO", "", agora=agora, resolucao="Recurso normalizado ou removido")
        for chave in [k for k in list(self.inc._pendentes) if k.startswith(("nao-pronto:", "pendente:"))]:
            regra = "POD_NAO_PRONTO" if chave.startswith("nao-pronto:") else "POD_PENDENTE"
            if chave not in atuais[regra]:
                self.inc._pendentes.pop(chave, None)
        self.inc.condicao("SENTINELA_SEM_KUBERNETES", "sentinela:kube", False, "MEDIA", "", agora=agora,
                          resolucao="Acesso ao Kubernetes restabelecido")

    def kube_falhou(self, erro: str, agora: float) -> None:
        self.inc.condicao("SENTINELA_SEM_KUBERNETES", "sentinela:kube", True, "MEDIA",
                          "Sentinela sem acesso ao Kubernetes",
                          f"{erro}. Confira a ClusterRole e o ServiceAccount do chart sentinela.", "sentinela",
                          duracao=300, agora=agora)

    def _tem_agente(self) -> bool:
        ts = self.store.valor("SELECT MAX(ts) FROM estado WHERE chave LIKE 'agente:%'")
        return bool(ts and time.time() - ts < 300)

    def _cpu(self, host: str, pct: float, agora: float) -> None:
        self.inc.condicao("CPU_ALTA", f"cpu:{host}", pct >= self.lim.cpu_pct, "MEDIA",
                          f"CPU alta em {host} ({pct:.0f}%)", f"Limite: {self.lim.cpu_pct}% por 5 minutos.", host,
                          duracao=300, agora=agora, resolucao="CPU normalizada")

    def _memoria(self, host: str, pct: float, usada: float, total: float, agora: float) -> None:
        self.inc.condicao("MEMORIA_ALTA", f"memoria:{host}", pct >= self.lim.memoria_pct, "ALTA",
                          f"Memória alta em {host} ({pct:.0f}%)",
                          f"{usada / 1024 ** 3:.1f} GB usados de {total / 1024 ** 3:.1f} GB. Limite: {self.lim.memoria_pct}%.",
                          host, duracao=300, agora=agora, resolucao="Memória normalizada")

    # ----------------------------------------------------- métricas da API --
    def app(self, amb, m: dict | None, pods_api: int, agora: float) -> None:
        chave_metricas = f"metricas:{amb.id}"
        if pods_api and (m is None or m["pods"] == 0):
            desde = self._sem_metricas_desde.setdefault(amb.id, agora)
            self.inc.condicao("METRICAS_INDISPONIVEIS", chave_metricas, agora - desde >= 600, "MEDIA",
                              f"Sem métricas da API ({amb.nome})",
                              "O Sentinela não alcança a porta 9464 dos pods da API. Confira se o chart da aplicação "
                              "libera o namespace sentinela em networkPolicy.monitoringNamespaces.", amb.namespace,
                              agora=agora)
            return
        self._sem_metricas_desde.pop(amb.id, None)
        self.inc.condicao("METRICAS_INDISPONIVEIS", chave_metricas, False, "MEDIA", "", agora=agora,
                          resolucao="Métricas voltaram")
        if not m:
            return
        if m.get("db_up") is not None:
            self.inc.condicao("BANCO_INDISPONIVEL", f"banco:{amb.id}", m["db_up"] < 1, "CRITICA",
                              f"Banco de dados indisponível ({amb.nome})",
                              "A API não consegue falar com o MySQL. Veja o pod do banco e os logs da API.",
                              amb.namespace, duracao=60, agora=agora, resolucao="Banco respondendo")
        if m.get("jwt_idade") is not None:
            limite = amb.rotacao_jwt_segundos * 1.5 + 120
            self.inc.condicao("ROTACAO_JWT_ATRASADA", f"jwt:{amb.id}", m["jwt_idade"] > limite, "ALTA",
                              f"Rotação de chave JWT atrasada ({amb.nome})",
                              f"A chave ativa tem {m['jwt_idade'] / 60:.0f} min; a rotação deveria acontecer a cada "
                              f"{amb.rotacao_jwt_segundos / 60:.0f} min.", amb.namespace, agora=agora,
                              resolucao="Chave rotacionada")

    # ------------------------------------------------------- janelas --
    def janelas(self, agora: float) -> None:
        lim = self.lim
        s = self.store
        # SSH: força bruta por IP.
        atuais = set()
        for r in s.q("SELECT ip, COUNT(*) AS n, MAX(usuario) AS usuario FROM eventos WHERE tipo IN ('SSH_FALHA', "
                     "'SSH_USUARIO_INVALIDO') AND ts >= ? AND ip IS NOT NULL GROUP BY ip HAVING n >= ?",
                     (agora - 600, lim.ssh_falhas)):
            chave = f"ssh:{r['ip']}"
            atuais.add(chave)
            self.inc.condicao("SSH_FORCA_BRUTA", chave, True, "ALTA", f"Força bruta SSH de {r['ip']}",
                              f"{r['n']} tentativas de login SSH com falha em 10 minutos (último usuário tentado: "
                              f"{r['usuario']}). Restrinja a porta 22 no grupo de segurança ao seu IP.", r["ip"], agora=agora,
                              resolucao="Tentativas cessaram")
        for chave in self.inc.chaves_ativas("SSH_FORCA_BRUTA") - atuais:
            self.inc.condicao("SSH_FORCA_BRUTA", chave, False, "ALTA", "", agora=agora, resolucao="Tentativas cessaram")

        # Painel (SecureAccess e o próprio Sentinela): senhas erradas por IP.
        atuais = set()
        for r in s.q("SELECT ambiente, ip, COUNT(*) AS n FROM eventos WHERE tipo IN ('LOGIN_FALHA', 'SENTINELA_LOGIN_FALHA') "
                     "AND ts >= ? GROUP BY ambiente, ip HAVING n >= ?", (agora - 300, lim.login_falhas)):
            chave = f"login:{r['ambiente']}:{r['ip']}"
            atuais.add(chave)
            self.inc.condicao("LOGIN_FORCA_BRUTA", chave, True, "ALTA",
                              f"Senhas erradas em sequência ({self._amb_nome(r['ambiente'])})",
                              f"{r['n']} falhas de login em 5 minutos vindas de {r['ip'] or 'IP desconhecido'}.",
                              r["ip"] or "", agora=agora, resolucao="Tentativas cessaram")
        for chave in self.inc.chaves_ativas("LOGIN_FORCA_BRUTA") - atuais:
            self.inc.condicao("LOGIN_FORCA_BRUTA", chave, False, "ALTA", "", agora=agora, resolucao="Tentativas cessaram")

        for a in self.cfg.ambientes:
            http = s.contagem(f"http:{a.id}", agora - 300)
            erros = s.contagem(f"http5xx:{a.id}", agora - 300)
            ativa = erros >= 10 or (http >= 20 and 100 * erros / max(http, 1) >= lim.erros_5xx_pct)
            self.inc.condicao("ERROS_5XX", f"5xx:{a.id}", ativa, "ALTA", f"API respondendo com erro ({a.nome})",
                              f"{erros} respostas 5xx de {http} requisições em 5 minutos.", a.namespace, agora=agora,
                              resolucao="Taxa de erro normalizada")
            erros_app = s.contagem(f"erro_app:{a.id}", agora - 300)
            self.inc.condicao("ERROS_APLICACAO", f"erros-app:{a.id}", erros_app >= 5, "ALTA",
                              f"Erros internos na API ({a.nome})",
                              f"{erros_app} erros internos em 5 minutos. Veja a página Segurança, filtro 'Erro interno'.",
                              a.namespace, agora=agora, resolucao="Erros cessaram")
            alertas = s.contagem(f"alerta:{a.id}", agora - 600)
            self.inc.condicao("PICO_ALERTAS", f"pico:{a.id}", alertas >= lim.pico_alertas, "ALTA",
                              f"Pico de alertas de segurança ({a.nome})",
                              f"{alertas} alertas da aplicação em 10 minutos (limite: {lim.pico_alertas}).", a.namespace,
                              agora=agora, resolucao="Volume de alertas normalizado")
            visto = s.estado_ts(f"syslog_visto:{a.id}")
            silencio = visto is not None and agora - visto > lim.silencio_min * 60
            self.inc.condicao("SYSLOG_SILENCIOSO", f"silencio:{a.id}", silencio, "MEDIA",
                              f"Syslog silencioso ({a.nome})",
                              f"Nenhuma mensagem há {(agora - (visto or agora)) / 60:.0f} min. Confira o rsyslog do servidor "
                              "(systemctl status rsyslog) e os pods da API.", a.namespace, agora=agora,
                              resolucao="Mensagens voltaram")

        # Agente do servidor: sinal de vida, CPU, memória e disco.
        for chave, (ts, d) in s.estados("agente:").items():
            host = chave.split(":", 1)[1]
            self.inc.condicao("AGENTE_SEM_SINAL", f"agente:{host}", agora - ts > 300, "MEDIA",
                              f"Agente de {host} sem sinal",
                              f"Última métrica há {(agora - ts) / 60:.0f} min. Veja: sudo systemctl status sentinela-agente",
                              host, agora=agora, resolucao="Agente voltou")
            if agora - ts > 300 or not isinstance(d, dict):
                continue
            if d.get("cpu_pct") is not None:
                self._cpu(host, d["cpu_pct"], agora)
            if d.get("mem_total"):
                self._memoria(host, 100 * d["mem_usada"] / d["mem_total"], d["mem_usada"], d["mem_total"], agora)
            if d.get("disco_total"):
                pct = 100 * d["disco_usado"] / d["disco_total"]
                self.inc.condicao("DISCO_CHEIO", f"disco:{host}", pct >= lim.disco_pct, "CRITICA" if pct >= 90 else "ALTA",
                                  f"Disco de {host} em {pct:.0f}%",
                                  f"{d['disco_usado'] / 1024 ** 3:.1f} GB usados de {d['disco_total'] / 1024 ** 3:.1f} GB. "
                                  "Libere espaço apagando imagens de build antigas: docker image prune -f e docker builder prune -f.", host, agora=agora, resolucao="Espaço liberado")

        self.inc.encerrar_parados(agora)
