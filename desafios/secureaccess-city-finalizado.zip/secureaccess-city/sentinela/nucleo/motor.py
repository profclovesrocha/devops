"""Motor do Sentinela: liga o receptor de syslog, a gravação e os coletores.

Roda dentro do mesmo processo do painel web (um worker do gunicorn), em
threads próprias. Cada tarefa registra quando rodou e se falhou, e isso
aparece no próprio painel ("saúde do Sentinela").
"""
from __future__ import annotations

import json
import logging
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from . import coleta
from .eventos import Processador
from .incidentes import Incidentes, Notificador
from .regras import Regras
from .store import Store
from .syslog import Receptor

log = logging.getLogger("sentinela")


class Tarefa:
    def __init__(self, nome: str, intervalo: float, funcao, atraso_inicial: float = 0):
        self.nome = nome
        self.intervalo = intervalo
        self.funcao = funcao
        self.proxima = time.time() + atraso_inicial
        self.ultimo_ok: float | None = None
        self.ultimo_erro: str | None = None
        self.ultimo_erro_ts: float | None = None
        self.duracao_ms: float | None = None
        self.rodando = False


class Motor:
    def __init__(self, cfg, store: Store | None = None):
        self.cfg = cfg
        self.store = store or Store(cfg.banco)
        self.fila: "queue.Queue" = queue.Queue(maxsize=50_000)
        self.receptor = Receptor(cfg.syslog_porta, self.fila, cfg.syslog_origens)
        self.processador = Processador(cfg)
        self.notificador = Notificador(cfg.telegram_token, cfg.telegram_chat, cfg.url_publica)
        self.incidentes = Incidentes(self.store, self.notificador)
        self.regras = Regras(cfg, self.store, self.incidentes)
        self.kube = coleta.Kube(cfg.kube_url, cfg.kube_token_arquivo, cfg.kube_ca_arquivo) if cfg.kube_ativo else None
        self.iniciado_em = time.time()
        self.gravadas = 0
        self._parar = threading.Event()
        self._threads: list[threading.Thread] = []
        self._pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="checagem")
        self._contadores_check: dict[str, dict] = {}
        self.tarefas = [
            Tarefa("checagens", cfg.intervalo_checagens, self.rodar_checagens, 3),
            Tarefa("certificados", 1800, self.rodar_tls, 5),
            Tarefa("kubernetes", cfg.intervalo_kube, self.rodar_kube, 2),
            Tarefa("regras", 30, self.rodar_janelas, 20),
            Tarefa("limpeza", 900, self.rodar_limpeza, 60),
            Tarefa("estado", 15, self.gravar_estado_interno, 1),
        ]

    # ------------------------------------------------------------- ciclo --
    def iniciar(self, receptor: bool = True, coletores: bool = True) -> None:
        if receptor:
            self.receptor.iniciar()
        self._iniciar_thread(self._laco_gravacao, "gravacao")
        if coletores:
            self._iniciar_thread(self._laco_agenda, "agenda")
        log.info(json.dumps({"evento": "SENTINELA_INICIADO", "syslog_porta": self.cfg.syslog_porta,
                             "ambientes": [a.id for a in self.cfg.ambientes], "kubernetes": bool(self.kube),
                             "telegram": self.notificador.ativo}))

    def _iniciar_thread(self, alvo, nome: str) -> None:
        t = threading.Thread(target=alvo, name=nome, daemon=True)
        t.start()
        self._threads.append(t)

    def parar(self) -> None:
        self._parar.set()
        self.receptor.parar()
        self._drenar()
        self._pool.shutdown(wait=False, cancel_futures=True)

    # ---------------------------------------------------------- gravação --
    def _drenar(self, espera: float = 0) -> int:
        lote = []
        try:
            lote.append(self.fila.get(timeout=espera) if espera else self.fila.get_nowait())
            while len(lote) < 2000:
                lote.append(self.fila.get_nowait())
        except queue.Empty:
            pass
        if not lote:
            return 0
        sinais = self.processador.processar(self.store, lote)
        self.gravadas += len(lote)
        for s in sinais:
            self.incidentes.ocorrencia(s.regra, s.chave, s.severidade, s.titulo, s.detalhe, s.alvo)
        return len(lote)

    def _laco_gravacao(self) -> None:
        while not self._parar.is_set():
            try:
                self._drenar(espera=1.0)
            except Exception as exc:  # banco ocupado, disco cheio...
                log.error(json.dumps({"evento": "GRAVACAO_FALHOU", "erro": str(exc)[:300]}))
                time.sleep(2)

    # ------------------------------------------------------------ agenda --
    def _laco_agenda(self) -> None:
        while not self._parar.is_set():
            agora = time.time()
            for t in self.tarefas:
                if t.rodando or agora < t.proxima:
                    continue
                t.proxima = agora + t.intervalo
                t.rodando = True
                threading.Thread(target=self._executar, args=(t,), name=f"tarefa-{t.nome}", daemon=True).start()
            self._parar.wait(1.0)

    def _executar(self, t: Tarefa) -> None:
        inicio = time.perf_counter()
        try:
            t.funcao()
            t.ultimo_ok = time.time()
        except Exception as exc:
            t.ultimo_erro = str(exc)[:300]
            t.ultimo_erro_ts = time.time()
            log.warning(json.dumps({"evento": "TAREFA_FALHOU", "tarefa": t.nome, "erro": t.ultimo_erro}))
        finally:
            t.duracao_ms = round((time.perf_counter() - inicio) * 1000, 1)
            t.rodando = False

    def rodar_agora(self, nome: str) -> None:
        for t in self.tarefas:
            if t.nome == nome:
                self._executar(t)

    # --------------------------------------------------------- checagens --
    def alvos(self) -> list[tuple]:
        """(ambiente, id do alvo, nome, url, texto esperado)"""
        saida = []
        for a in self.cfg.ambientes:
            if not a.url:
                continue
            saida.append((a, f"{a.id}:api", "API", f"{a.url}/api/info", "secureaccess-api"))
            saida.append((a, f"{a.id}:front", "Painel", f"{a.url}/login", "SecureAccess"))
        return saida

    def rodar_checagens(self) -> None:
        alvos = self.alvos()
        if not alvos:
            return
        futuros = [(a, alvo, nome, self._pool.submit(coleta.checar_http, url, contem)) for a, alvo, nome, url, contem in alvos]
        agora = time.time()
        linhas = []
        for a, alvo, nome, fut in futuros:
            r = fut.result()
            anterior = self._contadores_check.get(alvo) or self.store.estado(f"check:{alvo}") or {}
            falhas = 0 if r["ok"] else int(anterior.get("falhas_seguidas") or 0) + 1
            lento = r["ok"] and (r["latencia_ms"] or 0) > self.cfg.limiares.latencia_ms
            lentas = int(anterior.get("lentas_seguidas") or 0) + 1 if lento else 0
            mudou = anterior.get("ok") is None or bool(anterior.get("ok")) != r["ok"]
            estado = {
                **r, "ambiente": a.id, "ambiente_nome": a.nome, "alvo": alvo, "nome": nome,
                "falhas_seguidas": falhas, "lentas_seguidas": lentas,
                "desde": agora if mudou else anterior.get("desde", agora),
            }
            self._contadores_check[alvo] = estado
            self.store.gravar_estado(f"check:{alvo}", estado, agora)
            linhas.append((agora, alvo, 1 if r["ok"] else 0, r["status"], r["latencia_ms"], r["erro"]))
            self.regras.checagem(a, alvo, nome, r, falhas, lentas, agora)
        with self.store.transacao() as c:
            c.executemany("INSERT INTO checagens (ts, alvo, ok, status, latencia_ms, erro) VALUES (?, ?, ?, ?, ?, ?)", linhas)

    def rodar_tls(self) -> None:
        vistos = set()
        for a in self.cfg.ambientes:
            if not a.url:
                continue
            host, porta, esquema = coleta.host_de(a.url)
            if esquema != "https" or host in vistos:
                continue
            vistos.add(host)
            r = coleta.checar_tls(host, porta)
            r["ambiente"] = a.id
            self.store.gravar_estado(f"tls:{host}", r)
            self.regras.tls(host, r, time.time())

    # -------------------------------------------------------- kubernetes --
    def rodar_kube(self) -> None:
        if not self.kube:
            return
        agora = time.time()
        try:
            retrato = coleta.coletar_kube(self.kube)
        except coleta.KubeErro as exc:
            self.store.gravar_estado("kube:erro", {"erro": str(exc)}, agora)
            self.regras.kube_falhou(str(exc), agora)
            raise
        self.store.gravar_estado("kube", retrato, agora)
        series = []
        for n in retrato["nos"]:
            if n.get("cpu_uso") is not None and n["cpu_nucleos"]:
                series.append((f"no:{n['nome']}:cpu_pct", 100 * n["cpu_uso"] / n["cpu_nucleos"]))
            if n.get("memoria_uso") is not None and n["memoria_bytes"]:
                series.append((f"no:{n['nome']}:mem_pct", 100 * n["memoria_uso"] / n["memoria_bytes"]))
        prontos = sum(1 for p in retrato["pods"] if p["pronto"] or p["fase"] == "Succeeded")
        series.append(("cluster:pods_prontos", prontos))
        series.append(("cluster:pods_total", len(retrato["pods"])))
        self.store.amostras(series, agora)
        self.regras.kube(retrato, agora)
        self._metricas_app(retrato, agora)

    def _metricas_app(self, retrato: dict, agora: float) -> None:
        for a in self.cfg.ambientes:
            pods = [p for p in retrato["pods"] if p["namespace"] == a.namespace and p["componente"] == "api"
                    and p["fase"] == "Running" and p["pronto"] and p["ip"]]
            amostras, erros = [], []
            for p in pods:
                porta = p["porta_metricas"] or 9464
                try:
                    amostras.append(coleta.raspar(f"http://{p['ip']}:{porta}/metrics"))
                except Exception as exc:
                    erros.append(f"{p['nome']}: {coleta._explicar(exc)}")
            resumo = coleta.resumir_metricas_app(amostras) if amostras else None
            estado = {"pods_api": len(pods), "raspados": len(amostras), "erros": erros, **(resumo or {})}
            self.store.gravar_estado(f"app:{a.id}", estado, agora)
            if resumo:
                series = [(f"app:{a.id}:{k}", resumo[k]) for k in ("db_up", "jwt_idade", "jwt_chaves") if resumo[k] is not None]
                self.store.amostras(series, agora)
            self.regras.app(a, resumo, len(pods), agora)

    # ------------------------------------------------------------ outros --
    def rodar_janelas(self) -> None:
        self.regras.janelas(time.time())

    def rodar_limpeza(self) -> None:
        removidos = self.store.limpar(self.cfg.retencao_syslog_horas, self.cfg.retencao_eventos_dias)
        self.store.gravar_estado("limpeza", removidos)

    def saude(self) -> dict:
        r = self.receptor
        return {
            "iniciado_em": self.iniciado_em,
            "syslog": {"porta": self.cfg.syslog_porta, "recebidas": r.recebidas, "descartadas": r.descartadas,
                       "recusadas": r.recusadas, "conexoes_tcp": r.conexoes_tcp, "fila": self.fila.qsize(),
                       "gravadas": self.gravadas, "json_invalido": self.processador.json_invalido},
            "tarefas": [{"nome": t.nome, "intervalo": t.intervalo, "ultimo_ok": t.ultimo_ok, "ultimo_erro": t.ultimo_erro,
                         "ultimo_erro_ts": t.ultimo_erro_ts, "duracao_ms": t.duracao_ms} for t in self.tarefas],
            "telegram": {"ativo": self.notificador.ativo, "falhas": self.notificador.falhas,
                         "ultimo_erro": self.notificador.ultimo_erro},
            "kubernetes": bool(self.kube),
            "banco_bytes": self.store.tamanho_bytes(),
        }

    def gravar_estado_interno(self) -> None:
        self.store.gravar_estado("sentinela", self.saude())
