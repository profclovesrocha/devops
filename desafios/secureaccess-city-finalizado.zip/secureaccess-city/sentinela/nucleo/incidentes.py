"""Incidentes do Sentinela: abertura, deduplicação, resolução e avisos.

Dois tipos de incidente:
- por condição (site fora do ar, disco cheio...): abre quando a condição
  vale e se resolve sozinho quando ela deixa de valer;
- por evento (alerta crítico da aplicação, falta de memória...): abre a cada
  ocorrência nova, soma as repetições e se encerra sozinho depois de um
  tempo sem repetir.

Um incidente aberto nunca é duplicado: a chave (regra + alvo) é única entre
os incidentes ativos.
"""
from __future__ import annotations

import json
import logging
import queue
import threading
import time
import urllib.parse
import urllib.request

log = logging.getLogger("sentinela.incidentes")

SEVERIDADES = ["INFO", "MEDIA", "ALTA", "CRITICA"]
SEVERIDADE_PT = {"INFO": "Informativo", "MEDIA": "Média", "ALTA": "Alta", "CRITICA": "Crítica"}
ENCERRAMENTO_POR_EVENTO = 30 * 60  # segundos sem repetir até encerrar sozinho


def nivel(sev: str) -> int:
    try:
        return SEVERIDADES.index(sev)
    except ValueError:
        return 0


class Notificador:
    """Envia avisos pelo Telegram (opcional), numa thread própria e com limite."""

    def __init__(self, token: str | None, chat: str | None, url_publica: str | None = None,
                 severidade_minima: str = "ALTA", limite_hora: int = 30):
        self.ativo = bool(token and chat)
        self.token = token
        self.chat = chat
        self.url_publica = url_publica
        self.minimo = nivel(severidade_minima)
        self.limite_hora = limite_hora
        self.enviados: list[float] = []
        self.falhas = 0
        self.ultimo_erro: str | None = None
        self.fila: "queue.Queue[str]" = queue.Queue(maxsize=200)
        if self.ativo:
            threading.Thread(target=self._laco, name="notificador", daemon=True).start()

    def avisar(self, severidade: str, texto: str) -> None:
        if not self.ativo or nivel(severidade) < self.minimo:
            return
        try:
            self.fila.put_nowait(texto)
        except queue.Full:
            pass

    def _laco(self) -> None:
        while True:
            texto = self.fila.get()
            agora = time.time()
            self.enviados = [t for t in self.enviados if agora - t < 3600]
            if len(self.enviados) >= self.limite_hora:
                continue  # proteção contra enxurrada de avisos
            if self.url_publica:
                texto += f"\n{self.url_publica}/incidentes"
            dados = urllib.parse.urlencode({"chat_id": self.chat, "text": texto,
                                            "disable_web_page_preview": "true"}).encode()
            try:
                req = urllib.request.Request(f"https://api.telegram.org/bot{self.token}/sendMessage", data=dados)
                with urllib.request.urlopen(req, timeout=10) as r:
                    r.read()
                self.enviados.append(agora)
                self.ultimo_erro = None
            except Exception as exc:  # rede, token errado...
                self.falhas += 1
                # Nunca registra a URL (ela contém o token).
                self.ultimo_erro = type(exc).__name__
                log.warning("falha ao enviar aviso pelo Telegram: %s", type(exc).__name__)


class Incidentes:
    def __init__(self, store, notificador: Notificador | None = None):
        self.store = store
        self.notificador = notificador
        self._pendentes: dict[str, float] = {}  # condição verdadeira desde (para regras com duração)
        self._trava = threading.Lock()

    # ---------------------------------------------------------------- base --
    def ativo(self, chave: str) -> dict | None:
        return self.store.um("SELECT * FROM incidentes WHERE chave = ? AND status != 'RESOLVIDO'", (chave,))

    def abrir(self, regra: str, chave: str, severidade: str, titulo: str, detalhe: str = "", alvo: str = "",
              por_condicao: bool = True, agora: float | None = None) -> tuple[int, bool]:
        """Abre o incidente ou atualiza o que já está aberto. Devolve (id, novo)."""
        agora = agora or time.time()
        with self._trava:
            atual = self.ativo(chave)
            if atual:
                sev = severidade if nivel(severidade) > nivel(atual["severidade"]) else atual["severidade"]
                escalou = sev != atual["severidade"]
                self.store.executar(
                    "UPDATE incidentes SET atualizado_em = ?, detalhe = ?, severidade = ?, titulo = ?, "
                    "ocorrencias = ocorrencias + ? WHERE id = ?",
                    (agora, detalhe[:1000], sev, titulo[:200], 0 if por_condicao else 1, atual["id"]),
                )
                if escalou:
                    self._avisar(sev, f"⬆ Incidente agravado ({SEVERIDADE_PT[sev]}): {titulo}\n{detalhe}")
                return atual["id"], False
            novo_id = self.store.executar(
                "INSERT INTO incidentes (regra, chave, severidade, titulo, detalhe, alvo, status, por_condicao, aberto_em, "
                "atualizado_em) VALUES (?, ?, ?, ?, ?, ?, 'ABERTO', ?, ?, ?)",
                (regra, chave, severidade, titulo[:200], detalhe[:1000], alvo[:200], 1 if por_condicao else 0, agora, agora),
            )
        self._avisar(severidade, f"🚨 {SEVERIDADE_PT.get(severidade, severidade)}: {titulo}\n{detalhe}")
        return novo_id, True

    def resolver(self, chave: str, resolucao: str = "Condição normalizada", agora: float | None = None,
                 usuario: str | None = None) -> bool:
        agora = agora or time.time()
        with self._trava:
            atual = self.ativo(chave)
            if not atual:
                return False
            self.store.executar(
                "UPDATE incidentes SET status = 'RESOLVIDO', resolvido_em = ?, atualizado_em = ?, resolucao = ?, "
                "reconhecido_por = COALESCE(reconhecido_por, ?) WHERE id = ?",
                (agora, agora, resolucao[:300], usuario, atual["id"]),
            )
        if atual["status"] == "ABERTO" and usuario is None:
            self._avisar(atual["severidade"], f"✅ Resolvido: {atual['titulo']}")
        return True

    def reconhecer(self, incidente_id: int, usuario: str) -> bool:
        with self._trava:
            atual = self.store.um("SELECT * FROM incidentes WHERE id = ?", (incidente_id,))
            if not atual or atual["status"] != "ABERTO":
                return False
            self.store.executar(
                "UPDATE incidentes SET status = 'RECONHECIDO', reconhecido_por = ?, atualizado_em = ? WHERE id = ?",
                (usuario, time.time(), incidente_id),
            )
        return True

    def resolver_manual(self, incidente_id: int, usuario: str) -> bool:
        atual = self.store.um("SELECT chave, status FROM incidentes WHERE id = ?", (incidente_id,))
        if not atual or atual["status"] == "RESOLVIDO":
            return False
        return self.resolver(atual["chave"], f"Resolvido manualmente por {usuario}", usuario=usuario)

    def _avisar(self, severidade: str, texto: str) -> None:
        if self.notificador:
            self.notificador.avisar(severidade, texto)

    # ------------------------------------------------------- conveniências --
    def condicao(self, regra: str, chave: str, ativa: bool, severidade: str, titulo: str, detalhe: str = "",
                 alvo: str = "", duracao: float = 0, agora: float | None = None,
                 resolucao: str = "Condição normalizada") -> None:
        """Abre enquanto `ativa` for verdadeira por pelo menos `duracao` segundos; resolve quando deixa de ser."""
        agora = agora or time.time()
        if ativa:
            desde = self._pendentes.setdefault(chave, agora)
            if agora - desde >= duracao:
                self.abrir(regra, chave, severidade, titulo, detalhe, alvo, True, agora)
        else:
            self._pendentes.pop(chave, None)
            atual = self.ativo(chave)
            if atual and atual["por_condicao"]:
                self.resolver(chave, resolucao, agora)

    def ocorrencia(self, regra: str, chave: str, severidade: str, titulo: str, detalhe: str = "", alvo: str = "",
                   agora: float | None = None) -> None:
        self.abrir(regra, chave, severidade, titulo, detalhe, alvo, False, agora)

    def encerrar_parados(self, agora: float | None = None) -> int:
        """Encerra incidentes por evento que não se repetem há um tempo."""
        agora = agora or time.time()
        parados = self.store.q(
            "SELECT chave FROM incidentes WHERE status != 'RESOLVIDO' AND por_condicao = 0 AND atualizado_em < ?",
            (agora - ENCERRAMENTO_POR_EVENTO,))
        for p in parados:
            self.resolver(p["chave"], "Encerrado automaticamente: sem novas ocorrências há 30 minutos", agora)
        return len(parados)

    def chaves_ativas(self, regra: str) -> set[str]:
        return {r["chave"] for r in self.store.q(
            "SELECT chave FROM incidentes WHERE regra = ? AND status != 'RESOLVIDO' AND por_condicao = 1", (regra,))}

    def resumo(self) -> dict:
        linhas = self.store.q("SELECT severidade, status, COUNT(*) AS n FROM incidentes WHERE status != 'RESOLVIDO' "
                              "GROUP BY severidade, status")
        por_sev = {s: 0 for s in SEVERIDADES}
        abertos = reconhecidos = 0
        for r in linhas:
            por_sev[r["severidade"]] = por_sev.get(r["severidade"], 0) + r["n"]
            if r["status"] == "ABERTO":
                abertos += r["n"]
            else:
                reconhecidos += r["n"]
        return {"abertos": abertos, "reconhecidos": reconhecidos, "por_severidade": por_sev}


def para_json(incidente: dict) -> dict:
    d = dict(incidente)
    d["severidade_nome"] = SEVERIDADE_PT.get(d["severidade"], d["severidade"])
    return json.loads(json.dumps(d, default=str))
