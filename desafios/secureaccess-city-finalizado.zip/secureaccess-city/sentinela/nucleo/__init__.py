"""Núcleo do Sentinela: syslog, coleta, regras e armazenamento."""
