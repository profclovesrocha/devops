#!/usr/bin/env python3
"""Agente do Sentinela para servidores Linux.

Manda para o Sentinela, por syslog TCP (RFC 5424, contagem de octetos):
- a ficha da máquina (sistema, kernel, processador, memória, disco) a cada 10 min;
- CPU, memória, disco, carga, rede e processos a cada 30 s;
- linhas do journal que importam para segurança: logins SSH (com e sem
  sucesso), uso de sudo e processos mortos por falta de memória.

Só usa a biblioteca padrão do Python 3. Roda como serviço do systemd com
usuário dinâmico (sem root); lê o journal pelo grupo systemd-journal.

Variáveis:
  SENTINELA_DESTINO   IP ou nome do Sentinela (obrigatório)
  SENTINELA_PORTA     porta syslog TCP (padrão 30514, o NodePort do chart)
  SENTINELA_INTERVALO segundos entre medições (padrão 30)
  SENTINELA_ESTADO    pasta para guardar o cursor do journal (padrão /var/lib/sentinela-agente)
"""
from __future__ import annotations

import json
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import time
from collections import deque
from datetime import datetime, timezone

VERSAO = "1.0.0"
APP = "sentinela-agente"
DESTINO = os.environ.get("SENTINELA_DESTINO", "")
PORTA = int(os.environ.get("SENTINELA_PORTA", "30514"))
INTERVALO = max(5, int(os.environ.get("SENTINELA_INTERVALO", "30")))
ESTADO = os.environ.get("SENTINELA_ESTADO") or os.environ.get("STATE_DIRECTORY") or "/var/lib/sentinela-agente"
HOST = socket.gethostname()
FILTRO_SSH = re.compile(r"Failed |Invalid user|Accepted |maximum authentication attempts")
FILTRO_SUDO = re.compile(r"COMMAND=|incorrect password|authentication failure")
FILTRO_KERNEL = re.compile(r"Out of memory|oom-kill|Killed process")

_parar = False


def log(evento: str, **campos) -> None:
    print(json.dumps({"ts": datetime.now(timezone.utc).isoformat(), "evento": evento, **campos}, ensure_ascii=False),
          flush=True)


# ------------------------------------------------------------- medições --

def _ler(caminho: str) -> str:
    try:
        with open(caminho, encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def _cpu_tempos() -> tuple[int, int]:
    linha = _ler("/proc/stat").splitlines()[0].split()
    valores = [int(v) for v in linha[1:]]
    ocioso = valores[3] + (valores[4] if len(valores) > 4 else 0)  # idle + iowait
    return sum(valores), ocioso


def _memoria() -> dict:
    campos = {}
    for linha in _ler("/proc/meminfo").splitlines():
        nome, _, resto = linha.partition(":")
        partes = resto.split()
        if partes:
            campos[nome] = int(partes[0]) * 1024
    total = campos.get("MemTotal", 0)
    disponivel = campos.get("MemAvailable", campos.get("MemFree", 0))
    return {"mem_total": total, "mem_disponivel": disponivel, "mem_usada": max(0, total - disponivel),
            "swap_total": campos.get("SwapTotal", 0),
            "swap_usada": max(0, campos.get("SwapTotal", 0) - campos.get("SwapFree", 0))}


def _rede() -> tuple[int, int]:
    rx = tx = 0
    for linha in _ler("/proc/net/dev").splitlines()[2:]:
        nome, _, dados = linha.partition(":")
        nome = nome.strip()
        # Só interfaces físicas: ignora loopback e as virtuais do Kubernetes/Docker.
        if nome == "lo" or nome.startswith(("cali", "veth", "vxlan", "tunl", "docker", "br-", "cni", "flannel", "kube")):
            continue
        partes = dados.split()
        if len(partes) >= 9:
            rx += int(partes[0])
            tx += int(partes[8])
    return rx, tx


def _ip_privado() -> str | None:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect((DESTINO or "1.1.1.1", PORTA))
            return s.getsockname()[0]
    except OSError:
        return None


def ficha() -> dict:
    os_release = {}
    for linha in _ler("/etc/os-release").splitlines():
        if "=" in linha:
            k, v = linha.split("=", 1)
            os_release[k] = v.strip().strip('"')
    modelo = ""
    for linha in _ler("/proc/cpuinfo").splitlines():
        if linha.startswith("model name"):
            modelo = linha.split(":", 1)[1].strip()
            break
    uptime = float((_ler("/proc/uptime").split() or ["0"])[0])
    disco = shutil.disk_usage("/")
    return {
        "hostname": HOST,
        "sistema": os_release.get("PRETTY_NAME") or "Linux",
        "kernel": os.uname().release,
        "arquitetura": os.uname().machine,
        "cpu_modelo": modelo,
        "nucleos": os.cpu_count(),
        "mem_total": _memoria()["mem_total"],
        "disco_total": disco.total,
        "boot": time.time() - uptime,
        "ip_privado": _ip_privado(),
        "agente": VERSAO,
        "python": sys.version.split()[0],
    }


class Medidor:
    def __init__(self):
        self.cpu_anterior = _cpu_tempos()
        self.rede_anterior = (_rede(), time.monotonic())

    def medir(self) -> dict:
        total, ocioso = _cpu_tempos()
        t0, o0 = self.cpu_anterior
        self.cpu_anterior = (total, ocioso)
        delta = total - t0
        cpu = 100.0 * (1 - (ocioso - o0) / delta) if delta > 0 else 0.0
        (rx0, tx0), m0 = self.rede_anterior
        (rx, tx), m1 = _rede(), time.monotonic()
        self.rede_anterior = ((rx, tx), m1)
        dt = max(0.001, m1 - m0)
        carga = os.getloadavg()
        disco = shutil.disk_usage("/")
        processos = sum(1 for p in os.listdir("/proc") if p.isdigit())
        return {
            "cpu_pct": round(max(0.0, min(100.0, cpu)), 1),
            "load1": round(carga[0], 2), "load5": round(carga[1], 2), "load15": round(carga[2], 2),
            **_memoria(),
            "disco_total": disco.total, "disco_usado": disco.used, "disco_livre": disco.free,
            "rede_rx_bps": round(max(0, rx - rx0) / dt), "rede_tx_bps": round(max(0, tx - tx0) / dt),
            "uptime": float((_ler("/proc/uptime").split() or ["0"])[0]),
            "processos": processos,
        }


# --------------------------------------------------------------- journal --

class Journal:
    """Lê do journal só o que interessa, a partir do último ponto lido."""

    def __init__(self, pasta: str):
        self.cursor = os.path.join(pasta, "cursor")
        self.disponivel = shutil.which("journalctl") is not None
        self.aviso_dado = False

    def novas_linhas(self) -> list[dict]:
        if not self.disponivel:
            return []
        cmd = ["journalctl", "--no-pager", "-q", "-o", "json", f"--cursor-file={self.cursor}",
               "_COMM=sshd", "+", "_COMM=sshd-session", "+", "SYSLOG_IDENTIFIER=sudo", "+", "_TRANSPORT=kernel"]
        if not os.path.exists(self.cursor):
            cmd.insert(1, "--since=-10min")  # primeira vez: não relê o histórico inteiro
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.TimeoutExpired) as exc:
            if not self.aviso_dado:
                log("JOURNAL_INDISPONIVEL", erro=str(exc))
                self.aviso_dado = True
            return []
        if r.returncode != 0 and not r.stdout:
            if not self.aviso_dado:
                log("JOURNAL_SEM_PERMISSAO", erro=r.stderr.strip()[:300])
                self.aviso_dado = True
            return []
        linhas = []
        for bruto in r.stdout.splitlines()[-2000:]:
            try:
                e = json.loads(bruto)
            except ValueError:
                continue
            texto = e.get("MESSAGE")
            if isinstance(texto, list):  # mensagem binária vem como lista de bytes
                texto = bytes(texto).decode("utf-8", errors="replace")
            texto = str(texto or "")
            ident = e.get("SYSLOG_IDENTIFIER") or e.get("_COMM") or ""
            if e.get("_TRANSPORT") == "kernel":
                ident = "kernel"
                if not FILTRO_KERNEL.search(texto):
                    continue
            elif ident in ("sshd", "sshd-session"):
                if not FILTRO_SSH.search(texto):
                    continue
            elif ident == "sudo":
                if not FILTRO_SUDO.search(texto):
                    continue
            else:
                continue
            linhas.append({"ident": ident, "texto": texto[:1000], "pid": e.get("_PID"),
                           "ts": int(e.get("__REALTIME_TIMESTAMP", "0")) / 1e6})
        return linhas


# ---------------------------------------------------------------- envio --

class Envio:
    def __init__(self, destino: str, porta: int):
        self.destino = destino
        self.porta = porta
        self.sock: socket.socket | None = None
        self.pendentes: deque[bytes] = deque(maxlen=2000)
        self.falhou_desde: float | None = None

    @staticmethod
    def quadro(msgid: str, corpo: dict, severidade: int = 6, ts: float | None = None) -> bytes:
        pri = 16 * 8 + severidade  # local0
        quando = datetime.fromtimestamp(ts or time.time(), timezone.utc).isoformat(timespec="milliseconds")
        texto = json.dumps(corpo, ensure_ascii=False, separators=(",", ":"))
        msg = f"<{pri}>1 {quando} {HOST} {APP} {os.getpid()} {msgid} - {texto}".encode("utf-8")
        return f"{len(msg)} ".encode() + msg

    def enviar(self, quadros: list[bytes]) -> None:
        self.pendentes.extend(quadros)
        while self.pendentes:
            try:
                if self.sock is None:
                    self.sock = socket.create_connection((self.destino, self.porta), timeout=10)
                    self.sock.settimeout(10)
                    if self.falhou_desde:
                        log("CONEXAO_RESTABELECIDA", destino=self.destino, porta=self.porta,
                            fora_por_s=round(time.time() - self.falhou_desde))
                    self.falhou_desde = None
                self.sock.sendall(self.pendentes[0])
                self.pendentes.popleft()
            except OSError as exc:
                if self.falhou_desde is None:
                    self.falhou_desde = time.time()
                    log("ENVIO_FALHOU", destino=self.destino, porta=self.porta, erro=str(exc),
                        pendentes=len(self.pendentes))
                self.fechar()
                return

    def fechar(self) -> None:
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.sock = None


def _sinal(*_):
    global _parar
    _parar = True


def main() -> int:
    if not DESTINO:
        log("CONFIGURACAO_INVALIDA", erro="defina SENTINELA_DESTINO")
        return 2
    os.makedirs(ESTADO, exist_ok=True)
    signal.signal(signal.SIGTERM, _sinal)
    signal.signal(signal.SIGINT, _sinal)
    envio = Envio(DESTINO, PORTA)
    medidor = Medidor()
    journal = Journal(ESTADO)
    log("AGENTE_INICIADO", versao=VERSAO, destino=DESTINO, porta=PORTA, intervalo=INTERVALO,
        journal=journal.disponivel, host=HOST)
    proxima_ficha = 0.0
    time.sleep(1)  # primeira medição de CPU precisa de um intervalo
    while not _parar:
        agora = time.time()
        quadros = []
        if agora >= proxima_ficha:
            quadros.append(Envio.quadro("FICHA", ficha()))
            proxima_ficha = agora + 600
        quadros.append(Envio.quadro("METRICAS", medidor.medir()))
        for linha in journal.novas_linhas():
            sev = 2 if linha["ident"] == "kernel" else 4 if re.search(r"Failed|Invalid|incorrect|failure|maximum", linha["texto"]) else 5
            quadros.append(Envio.quadro("JOURNAL", linha, severidade=sev, ts=linha["ts"] or None))
        envio.enviar(quadros)
        for _ in range(INTERVALO * 10):
            if _parar:
                break
            time.sleep(0.1)
    envio.fechar()
    log("AGENTE_ENCERRADO")
    return 0


if __name__ == "__main__":
    sys.exit(main())
