#!/usr/bin/env bash
# Instala (ou atualiza) o agente do Sentinela neste servidor Linux.
# Uso: sudo bash agente/instalar-agente.sh <ip-ou-nome-do-sentinela> [porta]
# Exemplo, na própria VM do cluster: sudo bash agente/instalar-agente.sh 172.31.24.98 30514
set -euo pipefail

DESTINO="${1:?Informe o IP ou o nome do Sentinela. Ex.: sudo bash agente/instalar-agente.sh 172.31.24.98}"
PORTA="${2:-30514}"
AQUI="$(cd "$(dirname "$0")" && pwd)"

if [ "$(id -u)" -ne 0 ]; then
  echo "Rode com sudo." >&2
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  apt-get update -y && apt-get install -y python3
fi

install -d -m 0755 /opt/sentinela-agente
install -m 0644 "$AQUI/sentinela-agente.py" /opt/sentinela-agente/sentinela-agente.py
install -m 0644 "$AQUI/sentinela-agente.service" /etc/systemd/system/sentinela-agente.service
umask 022
cat > /etc/sentinela-agente.env <<CONF
SENTINELA_DESTINO=$DESTINO
SENTINELA_PORTA=$PORTA
SENTINELA_INTERVALO=30
CONF

systemctl daemon-reload
systemctl enable sentinela-agente >/dev/null 2>&1
systemctl restart sentinela-agente
sleep 2
if systemctl is-active --quiet sentinela-agente; then
  echo "Agente do Sentinela rodando, enviando para $DESTINO:$PORTA."
  echo "Acompanhe com: journalctl -u sentinela-agente -f"
else
  echo "O agente não subiu. Veja: journalctl -u sentinela-agente -n 30" >&2
  exit 1
fi
