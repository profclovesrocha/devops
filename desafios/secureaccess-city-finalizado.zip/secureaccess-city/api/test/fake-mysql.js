'use strict';

// Dublê de teste do pool do mysql2, usando o SQLite embutido no Node.
// Serve só para rodar os testes automatizados sem um servidor MySQL.
// Ele traduz o DDL da migração MySQL para SQLite, então o arquivo
// db/migrations/*.sql continua sendo a única fonte do esquema.

const { DatabaseSync } = require('node:sqlite');

const ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

function translateDdl(sql) {
  let s = sql.replace(/\)\s*ENGINE=[^;]*$/i, ')');
  s = s.replace(/\b(?:BIG)?INT AUTO_INCREMENT PRIMARY KEY/gi, 'INTEGER PRIMARY KEY AUTOINCREMENT');
  s = s.split('\n').filter((line) => !/^\s*(INDEX|KEY)\s/i.test(line)).join('\n');
  s = s.replace(/,(\s*)\)\s*$/, '$1)');
  return s;
}

function toParam(v) {
  if (v === undefined) throw new Error('Parâmetro undefined passado para o banco');
  if (v instanceof Date) return v.toISOString();
  if (typeof v === 'boolean') return v ? 1 : 0;
  return v;
}

function fromRow(row) {
  const out = {};
  for (const [k, v] of Object.entries(row)) out[k] = typeof v === 'string' && ISO.test(v) ? new Date(v) : v;
  return out;
}

function createFakePool() {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  let txLock = Promise.resolve();

  async function query(sql, params = []) {
    const text = sql.trim();
    if (/GET_LOCK|RELEASE_LOCK/i.test(text)) return [[{ l: 1, r: 1 }], []];
    if (/^CREATE\s+TABLE/i.test(text)) {
      db.exec(translateDdl(text));
      return [{ affectedRows: 0, insertId: 0 }, undefined];
    }
    if (/^(BEGIN|COMMIT|ROLLBACK)/i.test(text)) {
      db.exec(text);
      return [{ affectedRows: 0, insertId: 0 }, undefined];
    }
    const stmt = db.prepare(text);
    const bound = params.map(toParam);
    if (/^(SELECT|WITH)\b/i.test(text)) return [stmt.all(...bound).map(fromRow), []];
    const r = stmt.run(...bound);
    return [{ insertId: Number(r.lastInsertRowid), affectedRows: Number(r.changes) }, undefined];
  }

  return {
    raw: db,
    query,
    async getConnection() {
      let release = () => {};
      return {
        query,
        async beginTransaction() {
          const previous = txLock;
          txLock = new Promise((r) => { release = r; });
          await previous;
          db.exec('BEGIN');
        },
        async commit() { db.exec('COMMIT'); release(); },
        async rollback() { db.exec('ROLLBACK'); release(); },
        release() {},
      };
    },
    async end() { db.close(); },
  };
}

module.exports = { createFakePool, translateDdl };
