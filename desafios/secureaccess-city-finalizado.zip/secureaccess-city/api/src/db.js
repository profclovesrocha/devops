'use strict';

const fs = require('node:fs');
const path = require('node:path');

// Camada fina sobre o pool do mysql2. Todas as consultas usam parâmetros (?),
// nunca concatenação de valores no SQL.
class Database {
  constructor(pool) {
    this.pool = pool;
  }

  async q(sql, params = []) {
    const [rows] = await this.pool.query(sql, params);
    return rows;
  }

  async one(sql, params = []) {
    const rows = await this.q(sql, params);
    return rows[0] ?? null;
  }

  async exec(sql, params = []) {
    const [result] = await this.pool.query(sql, params);
    return result;
  }

  async tx(fn) {
    const conn = await this.pool.getConnection();
    const scoped = {
      q: async (sql, params = []) => (await conn.query(sql, params))[0],
      exec: async (sql, params = []) => (await conn.query(sql, params))[0],
    };
    try {
      await conn.beginTransaction();
      const result = await fn(scoped);
      await conn.commit();
      return result;
    } catch (err) {
      await conn.rollback().catch(() => {});
      throw err;
    } finally {
      conn.release();
    }
  }

  // Trava nomeada do MySQL (GET_LOCK). Garante que, com várias réplicas da
  // API, só uma execute migrações ou rotacione chaves ao mesmo tempo.
  // A trava pertence à conexão, então ela fica reservada até o fim.
  async withLock(name, timeoutSec, fn) {
    const conn = await this.pool.getConnection();
    try {
      const [rows] = await conn.query('SELECT GET_LOCK(?, ?) AS l', [name, timeoutSec]);
      if (Number(rows[0].l) !== 1) return { acquired: false };
      try {
        return { acquired: true, result: await fn() };
      } finally {
        await conn.query('SELECT RELEASE_LOCK(?) AS r', [name]).catch(() => {});
      }
    } finally {
      conn.release();
    }
  }

  async ping() {
    await this.pool.query('SELECT 1 AS ok');
  }

  async close() {
    await this.pool.end();
  }
}

function isDuplicate(err) {
  return err && (err.code === 'ER_DUP_ENTRY' || /UNIQUE constraint failed/i.test(err.message || ''));
}

function splitStatements(sql) {
  return sql
    .split('\n')
    .filter((line) => !line.trim().startsWith('--'))
    .join('\n')
    .split(/;\s*(?:\n|$)/)
    .map((s) => s.trim())
    .filter(Boolean);
}

async function migrate(db, logger, dir = path.join(__dirname, '..', 'db', 'migrations')) {
  const outcome = await db.withLock('secureaccess_migrations', 60, async () => {
    await db.exec(
      'CREATE TABLE IF NOT EXISTS schema_migrations (version INT PRIMARY KEY, name VARCHAR(120) NOT NULL, applied_at DATETIME(3) NOT NULL)',
    );
    const applied = new Set((await db.q('SELECT version FROM schema_migrations')).map((r) => Number(r.version)));
    const files = fs.readdirSync(dir).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
    for (const file of files) {
      const version = Number.parseInt(file, 10);
      if (applied.has(version)) continue;
      const statements = splitStatements(fs.readFileSync(path.join(dir, file), 'utf8'));
      for (const stmt of statements) await db.exec(stmt);
      await db.exec('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)', [version, file, new Date()]);
      logger.notice('MIGRACAO_APLICADA', { category: 'database', migration: file, statements: statements.length });
    }
  });
  if (!outcome.acquired) throw new Error('Não foi possível obter a trava de migração do banco');
}

function toDate(v) {
  if (v === null || v === undefined) return null;
  return v instanceof Date ? v : new Date(v);
}

module.exports = { Database, migrate, isDuplicate, splitStatements, toDate };
