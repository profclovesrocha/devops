'use strict';

const { BUILDINGS, DOORS, CITIZENS, fakeDocument, biometricTemplate } = require('./seed-data');
const { encryptField, blindIndex, hashPassword, verifyPassword, deviceSecret } = require('./crypto');

const OPERATORS = [
  { username: 'admin', role: 'ADMIN', key: 'admin' },
  { username: 'operador', role: 'OPERADOR', key: 'operador' },
  { username: 'auditor', role: 'AUDITOR', key: 'auditor' },
];

// Cria (ou sincroniza) os operadores a partir das senhas do Secret.
// O Secret é a fonte da verdade: trocar a senha lá e reiniciar a API
// atualiza o hash no banco.
async function ensureOperators(deps) {
  for (const op of OPERATORS) {
    const password = deps.cfg.operators[op.key];
    if (!password) continue;
    const existing = await deps.db.one('SELECT id, password_hash FROM operators WHERE username = ?', [op.username]);
    if (!existing) {
      await deps.db.exec(
        'INSERT INTO operators (username, password_hash, role, failed_attempts, created_at) VALUES (?, ?, ?, 0, ?)',
        [op.username, await hashPassword(password), op.role, new Date()],
      );
      deps.logger.notice('OPERADOR_CRIADO', { category: 'audit', actor: 'sistema', target: op.username, role: op.role });
    } else if (!(await verifyPassword(password, existing.password_hash))) {
      await deps.db.exec('UPDATE operators SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?', [
        await hashPassword(password), existing.id,
      ]);
      deps.logger.notice('SENHA_OPERADOR_SINCRONIZADA', { category: 'key_management', actor: 'sistema', target: op.username });
    }
  }
}

async function seedDemoData(deps) {
  const count = await deps.db.one('SELECT COUNT(*) AS n FROM buildings');
  if (Number(count.n) > 0) return false;

  const now = new Date();
  const { data, blindIndex: bik, deviceMaster } = deps.cfg.keys;
  const buildingIds = {};

  for (const b of BUILDINGS) {
    const r = await deps.db.exec(
      'INSERT INTO buildings (code, name, district, opens_at, closes_at, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      [b.code, b.name, b.district, b.opens, b.closes, now],
    );
    buildingIds[b.code] = Number(r.insertId);
  }

  for (const d of DOORS) {
    const secretHash = await hashPassword(deviceSecret(d.code, deviceMaster));
    await deps.db.exec(
      'INSERT INTO doors (code, building_id, name, kind, security_level, secret_hash, active, created_at) VALUES (?, ?, ?, ?, ?, ?, 1, ?)',
      [d.code, buildingIds[d.building], d.name, d.kind, d.level, secretHash, now],
    );
  }

  for (const [i, c] of CITIZENS.entries()) {
    const doc = fakeDocument(i + 1);
    const validUntil = c.validDays === null ? null : new Date(now.getTime() + c.validDays * 86400 * 1000);
    const r = await deps.db.exec(
      `INSERT INTO citizens (badge_number, name_enc, document_enc, document_hash, biometric_hash, category, department,
                             access_level, all_hours, status, valid_until, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        c.badge,
        encryptField(c.name, data, 'citizens.name'),
        encryptField(doc, data, 'citizens.document'),
        blindIndex(`doc:${doc}`, bik),
        c.biometric ? blindIndex(`bio:${biometricTemplate(c.badge)}`, bik) : null,
        c.category,
        c.department,
        c.level,
        c.allHours ? 1 : 0,
        c.status,
        validUntil,
        now,
        now,
      ],
    );
    const citizenId = Number(r.insertId);
    for (const code of c.buildings) {
      await deps.db.exec('INSERT INTO citizen_buildings (citizen_id, building_id) VALUES (?, ?)', [citizenId, buildingIds[code]]);
    }
  }

  deps.logger.notice('DADOS_DEMO_CRIADOS', {
    category: 'database', buildings: BUILDINGS.length, doors: DOORS.length, citizens: CITIZENS.length,
  });
  return true;
}

module.exports = { ensureOperators, seedDemoData, OPERATORS };
