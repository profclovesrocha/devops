'use strict';

const crypto = require('node:crypto');

class HttpError extends Error {
  constructor(status, code, message, extra) {
    super(message || code);
    this.status = status;
    this.code = code;
    this.extra = extra;
  }
}

class Router {
  constructor() {
    this.routes = [];
  }

  add(method, pattern, handler, opts = {}) {
    const keys = [];
    const source = pattern.replace(/:([a-zA-Z_]+)/g, (_, k) => {
      keys.push(k);
      return '([^/]+)';
    });
    this.routes.push({ method, pattern, re: new RegExp(`^${source}/?$`), keys, handler, opts });
  }

  match(method, pathname) {
    let pathMatched = false;
    for (const route of this.routes) {
      const m = route.re.exec(pathname);
      if (!m) continue;
      pathMatched = true;
      if (route.method !== method) continue;
      const params = {};
      route.keys.forEach((k, i) => {
        params[k] = decodeURIComponent(m[i + 1]);
      });
      return { route, params };
    }
    return { route: null, methodNotAllowed: pathMatched };
  }
}

const API_SECURITY_HEADERS = {
  'Content-Security-Policy': "default-src 'none'; frame-ancestors 'none'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Cache-Control': 'no-store',
  'Cross-Origin-Resource-Policy': 'same-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
};

function setSecurityHeaders(res, { hsts }) {
  for (const [k, v] of Object.entries(API_SECURITY_HEADERS)) res.setHeader(k, v);
  if (hsts) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
}

function sendJson(res, status, body) {
  if (res.writableEnded) return;
  const payload = JSON.stringify(body ?? {});
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Length', Buffer.byteLength(payload));
  res.end(payload);
}

// Remove chaves usadas em ataques de "prototype pollution".
function safeReviver(key, value) {
  if (key === '__proto__' || key === 'constructor' || key === 'prototype') return undefined;
  return value;
}

function readJson(req, limitBytes = 16 * 1024) {
  return new Promise((resolve, reject) => {
    const length = req.headers['content-length'];
    if ((length === undefined || length === '0') && !req.headers['transfer-encoding']) {
      req.resume();
      resolve({});
      return;
    }
    const type = String(req.headers['content-type'] || '');
    if (!type.toLowerCase().startsWith('application/json')) {
      reject(new HttpError(415, 'TIPO_NAO_SUPORTADO', 'Envie o corpo como application/json'));
      req.resume();
      return;
    }
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limitBytes) {
        reject(new HttpError(413, 'CORPO_GRANDE_DEMAIS', 'Corpo da requisição grande demais'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (size === 0) return resolve({});
      try {
        const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'), safeReviver);
        if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
          return reject(new HttpError(400, 'JSON_INVALIDO', 'O corpo precisa ser um objeto JSON'));
        }
        resolve(parsed);
      } catch {
        reject(new HttpError(400, 'JSON_INVALIDO', 'JSON inválido'));
      }
    });
    req.on('error', reject);
  });
}

// Com um único proxy confiável (Traefik), o IP real do cliente é o último
// valor de X-Forwarded-For, que é o que o próprio proxy acrescentou.
// Os valores anteriores vêm do cliente e podem ser forjados.
function clientIp(req, trustProxy) {
  const direct = req.socket?.remoteAddress || '';
  if (trustProxy) {
    const xff = String(req.headers['x-forwarded-for'] || '');
    const last = xff.split(',').map((s) => s.trim()).filter(Boolean).at(-1);
    if (last && /^[0-9a-fA-F:.]{3,45}$/.test(last)) return last;
  }
  return direct.replace(/^::ffff:/, '');
}

function requestId(req) {
  const given = String(req.headers['x-request-id'] || '');
  return /^[A-Za-z0-9-]{8,64}$/.test(given) ? given : crypto.randomUUID();
}

// Limitador simples por janela deslizante, em memória.
class RateLimiter {
  constructor() {
    this.hits = new Map();
    this.timer = setInterval(() => this.sweep(), 60 * 1000);
    this.timer.unref();
  }

  take(key, limit, windowSec) {
    const now = Date.now();
    const from = now - windowSec * 1000;
    const list = (this.hits.get(key) || []).filter((t) => t > from);
    if (list.length >= limit) {
      this.hits.set(key, list);
      return { ok: false, retryAfter: Math.max(1, Math.ceil((list[0] + windowSec * 1000 - now) / 1000)) };
    }
    list.push(now);
    this.hits.set(key, list);
    return { ok: true };
  }

  sweep() {
    const cutoff = Date.now() - 3600 * 1000;
    for (const [k, list] of this.hits) {
      if (!list.length || list[list.length - 1] < cutoff) this.hits.delete(k);
    }
  }

  stop() {
    clearInterval(this.timer);
  }
}

module.exports = { HttpError, Router, setSecurityHeaders, sendJson, readJson, clientIp, requestId, RateLimiter };
