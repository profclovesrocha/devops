'use strict';

const ALERT_TYPES = {
  FORCA_BRUTA: { severity: 'ALTA', label: 'Força bruta na leitora' },
  VARREDURA_CRACHA: { severity: 'ALTA', label: 'Crachá testado em várias portas' },
  CRACHA_REVOGADO_USO: { severity: 'ALTA', label: 'Uso de crachá revogado' },
  PORTA_FORCADA: { severity: 'CRITICA', label: 'Porta forçada (arrombamento)' },
  CARONA: { severity: 'ALTA', label: 'Entrada de carona (tailgating)' },
  PORTA_ABERTA_EXCEDIDO: { severity: 'MEDIA', label: 'Porta aberta além do tempo' },
  SABOTAGEM: { severity: 'CRITICA', label: 'Tentativa de violação do leitor' },
  DISPOSITIVO_NAO_AUTENTICADO: { severity: 'ALTA', label: 'Catraca falhando na autenticação' },
};

// Tipos que uma catraca/porta pode reportar diretamente (invasões físicas).
const DEVICE_EVENT_TYPES = ['PORTA_FORCADA', 'CARONA', 'PORTA_ABERTA_EXCEDIDO', 'SABOTAGEM'];

const LOG_LEVEL = { CRITICA: 'critical', ALTA: 'error', MEDIA: 'warning' };

async function createAlert(deps, { type, door = null, badgeRef = null, details, dedupSec = 0, dedupBy = 'door' }) {
  const def = ALERT_TYPES[type];
  if (!def) throw new Error(`Tipo de alerta desconhecido: ${type}`);
  const now = new Date();

  if (dedupSec > 0) {
    const since = new Date(now.getTime() - dedupSec * 1000);
    const existing = dedupBy === 'badge'
      ? await deps.db.one('SELECT id FROM security_alerts WHERE alert_type = ? AND badge_ref = ? AND occurred_at >= ? LIMIT 1', [type, badgeRef, since])
      : await deps.db.one('SELECT id FROM security_alerts WHERE alert_type = ? AND door_id = ? AND occurred_at >= ? LIMIT 1', [type, door ? door.id : null, since]);
    if (existing) return null;
  }

  const result = await deps.db.exec(
    'INSERT INTO security_alerts (occurred_at, alert_type, severity, door_id, building_id, badge_ref, details, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [now, type, def.severity, door ? door.id : null, door ? door.building_id : null, badgeRef, String(details).slice(0, 255), 'ABERTO'],
  );
  const id = Number(result.insertId);
  deps.metrics.inc('secureaccess_security_alerts_total', { type, severity: def.severity });
  deps.logger.log(LOG_LEVEL[def.severity], 'ALERTA_SEGURANCA', {
    category: 'security_alert',
    alert_id: id,
    alert_type: type,
    severity: def.severity,
    door: door ? door.code : null,
    building: door ? door.building_code : null,
    badge: badgeRef,
    details: String(details).slice(0, 255),
  });
  return { id, type, severity: def.severity, label: def.label };
}

module.exports = { ALERT_TYPES, DEVICE_EVENT_TYPES, createAlert };
