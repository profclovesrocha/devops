'use strict';

// Utilitários de fuso horário. O banco guarda tudo em UTC; regras de
// horário de funcionamento e "hoje" seguem o fuso da cidade.

const formatters = new Map();

function fmt(timeZone, opts) {
  const key = timeZone + JSON.stringify(opts);
  if (!formatters.has(key)) formatters.set(key, new Intl.DateTimeFormat('en-GB', { timeZone, ...opts }));
  return formatters.get(key);
}

function parts(date, timeZone) {
  const out = {};
  for (const p of fmt(timeZone, {
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
  }).formatToParts(date)) {
    if (p.type !== 'literal') out[p.type] = p.value;
  }
  return out;
}

function localHHMM(date, timeZone) {
  const p = parts(date, timeZone);
  return `${p.hour}:${p.minute}`;
}

function localTime(date, timeZone) {
  const p = parts(date, timeZone);
  return `${p.hour}:${p.minute}:${p.second}`;
}

function localDate(date, timeZone) {
  const p = parts(date, timeZone);
  return `${p.day}/${p.month}/${p.year}`;
}

function offsetMs(date, timeZone) {
  const p = parts(date, timeZone);
  const asUtc = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute), Number(p.second));
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

// Instante (UTC) da meia-noite local do dia de "date".
function startOfLocalDay(date, timeZone) {
  const p = parts(date, timeZone);
  const guess = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day));
  return new Date(guess - offsetMs(new Date(guess), timeZone));
}

function isWithinHours(date, timeZone, opens, closes) {
  const hhmm = localHHMM(date, timeZone);
  if (opens <= closes) return hhmm >= opens && hhmm <= closes;
  return hhmm >= opens || hhmm <= closes; // horário que atravessa a meia-noite
}

module.exports = { localHHMM, localTime, localDate, startOfLocalDay, isWithinHours };
