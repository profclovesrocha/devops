'use strict';

const { HttpError } = require('./http');

function fail(field, message) {
  throw new HttpError(422, 'DADOS_INVALIDOS', message, { field });
}

function str(body, field, { min = 1, max = 255, pattern, optional = false } = {}) {
  const v = body[field];
  if (v === undefined || v === null || v === '') {
    if (optional) return null;
    fail(field, `O campo "${field}" é obrigatório`);
  }
  if (typeof v !== 'string') fail(field, `O campo "${field}" precisa ser texto`);
  const s = v.trim();
  if (s.length < min || s.length > max) fail(field, `O campo "${field}" precisa ter entre ${min} e ${max} caracteres`);
  if (pattern && !pattern.test(s)) fail(field, `O campo "${field}" está em formato inválido`);
  return s;
}

function int(body, field, { min, max, optional = false } = {}) {
  const v = body[field];
  if (v === undefined || v === null || v === '') {
    if (optional) return null;
    fail(field, `O campo "${field}" é obrigatório`);
  }
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isInteger(n) || n < min || n > max) fail(field, `O campo "${field}" precisa ser um inteiro entre ${min} e ${max}`);
  return n;
}

function oneOf(body, field, allowed, { optional = false } = {}) {
  const v = body[field];
  if (v === undefined || v === null || v === '') {
    if (optional) return null;
    fail(field, `O campo "${field}" é obrigatório`);
  }
  if (!allowed.includes(v)) fail(field, `O campo "${field}" precisa ser um destes: ${allowed.join(', ')}`);
  return v;
}

function bool(body, field) {
  const v = body[field];
  if (v === undefined || v === null || v === '') return false;
  if (typeof v === 'boolean') return v;
  if (v === 'true' || v === '1' || v === 1) return true;
  if (v === 'false' || v === '0' || v === 0) return false;
  return fail(field, `O campo "${field}" precisa ser verdadeiro ou falso`);
}

function strList(body, field, { min = 0, max = 20, itemPattern } = {}) {
  const v = body[field];
  if (!Array.isArray(v)) fail(field, `O campo "${field}" precisa ser uma lista`);
  if (v.length < min || v.length > max) fail(field, `O campo "${field}" precisa ter entre ${min} e ${max} itens`);
  return [...new Set(v.map((item) => {
    if (typeof item !== 'string' || (itemPattern && !itemPattern.test(item))) fail(field, `Item inválido em "${field}"`);
    return item;
  }))];
}

function queryInt(params, name, { def, min, max }) {
  const raw = params.get(name);
  if (raw === null || raw === '') return def;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min || n > max) throw new HttpError(400, 'PARAMETRO_INVALIDO', `Parâmetro "${name}" inválido`);
  return n;
}

function queryStr(params, name, pattern) {
  const raw = params.get(name);
  if (raw === null || raw === '') return null;
  if (!pattern.test(raw)) throw new HttpError(400, 'PARAMETRO_INVALIDO', `Parâmetro "${name}" inválido`);
  return raw;
}

// Credenciais vindas do leitor podem ser qualquer coisa (inclusive tentativas
// de injeção). Esta função gera uma referência segura para logs e banco.
function safeBadgeRef(raw) {
  const s = String(raw ?? '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 20);
  return s || 'VAZIO';
}

module.exports = { str, int, oneOf, bool, strList, queryInt, queryStr, safeBadgeRef };
