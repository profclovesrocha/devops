'use strict';

const { Logger } = require('./logger');
const { createMetrics } = require('./metrics');
const { Database, migrate } = require('./db');
const { KeyRing } = require('./keyring');
const { ensureOperators, seedDemoData } = require('./seed');
const { registerRoutes, authenticate } = require('./routes');
const {
  HttpError, Router, setSecurityHeaders, sendJson, readJson, clientIp, requestId, RateLimiter,
} = require('./http');

function createApp({ cfg, pool, logOut }) {
  const logger = new Logger({ service: cfg.service, env: cfg.appEnv, version: cfg.version, syslog: cfg.syslog, out: logOut });
  const metrics = createMetrics();
  const db = new Database(pool);
  const limiter = new RateLimiter();
  const keyring = new KeyRing({
    db,
    kek: cfg.keys.jwtKek,
    logger,
    metrics,
    rotationIntervalSec: cfg.jwt.rotationIntervalSec,
    maxTokenTtlSec: Math.max(cfg.jwt.operatorTtlSec, cfg.jwt.deviceTtlSec),
  });
  const deps = { cfg, db, logger, metrics, limiter, keyring };
  const state = { ready: false, stopping: false };
  const router = new Router();
  registerRoutes(router, deps, state);
  const timers = [];

  async function handle(req, res) {
    const started = process.hrtime.bigint();
    const reqId = requestId(req);
    res.setHeader('X-Request-Id', reqId);
    setSecurityHeaders(res, { hsts: cfg.hsts });

    let url;
    try {
      url = new URL(req.url, 'http://localhost');
    } catch {
      sendJson(res, 400, { error: 'URL_INVALIDA', message: 'URL inválida' });
      return;
    }
    const { route, params, methodNotAllowed } = router.match(req.method, url.pathname);
    const ctx = {
      req, res, params, query: url.searchParams, ip: clientIp(req, cfg.trustProxy), reqId, route: route ? route.pattern : 'desconhecida',
    };

    try {
      if (!route) {
        throw methodNotAllowed
          ? new HttpError(405, 'METODO_NAO_PERMITIDO', 'Método não permitido')
          : new HttpError(404, 'NAO_ENCONTRADO', 'Rota não encontrada');
      }
      if (route.opts.auth && !state.ready) throw new HttpError(503, 'INICIALIZANDO', 'API ainda inicializando');
      if (route.opts.rateLimit) {
        const rl = route.opts.rateLimit;
        const r = limiter.take(`${rl.name}:${ctx.ip}`, rl.limit, rl.windowSec);
        if (!r.ok) {
          res.setHeader('Retry-After', String(r.retryAfter));
          logger.warning('LIMITE_REQUISICOES_EXCEDIDO', { category: 'authentication', route: ctx.route, source_ip: ctx.ip });
          throw new HttpError(429, 'MUITAS_TENTATIVAS', 'Muitas requisições; aguarde e tente novamente');
        }
      }
      ctx.body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readJson(req) : null;
      if (route.opts.auth) ctx.auth = await authenticate(deps, ctx, route.opts.auth, route.opts.roles);
      const out = await route.handler(ctx);
      if (out && typeof out.status === 'number' && out.body !== undefined) sendJson(res, out.status, out.body);
      else sendJson(res, 200, out);
    } catch (err) {
      if (err instanceof HttpError) {
        sendJson(res, err.status, { error: err.code, message: err.message, ...(err.extra || {}), request_id: reqId });
      } else {
        logger.error('ERRO_INTERNO', { category: 'application', route: ctx.route, request_id: reqId, error: err.message, stack: err.stack });
        sendJson(res, 500, { error: 'ERRO_INTERNO', message: 'Erro interno', request_id: reqId });
      }
    } finally {
      const seconds = Number(process.hrtime.bigint() - started) / 1e9;
      const status = String(res.statusCode);
      metrics.inc('secureaccess_http_requests_total', { route: ctx.route, method: req.method, status });
      metrics.inc('secureaccess_http_request_duration_seconds_sum', { route: ctx.route }, seconds);
      if (!(route && route.opts.quiet)) {
        logger.info('HTTP_REQUISICAO', {
          category: 'http', method: req.method, route: ctx.route, status: res.statusCode,
          duration_ms: Math.round(seconds * 1000), source_ip: ctx.ip, request_id: reqId,
        });
      }
    }
  }

  function handleMetrics(req, res) {
    const path = (req.url || '').split('?')[0];
    if (req.method === 'GET' && path === '/metrics') {
      const body = metrics.render();
      res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4; charset=utf-8' });
      res.end(body);
      return;
    }
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('not found\n');
  }

  async function init() {
    await db.ping();
    await migrate(db, logger);
    await ensureOperators(deps);
    if (cfg.seedDemoData) await seedDemoData(deps);
    await keyring.tick();
    state.ready = true;
    metrics.set('secureaccess_db_up', {}, 1);
    logger.notice('API_PRONTA', { category: 'application', environment: cfg.appEnv, commit: cfg.commit, simulation: cfg.allowSimulation });
  }

  async function initWithRetry({ attempts = 60, delayMs = 3000 } = {}) {
    for (let i = 1; i <= attempts && !state.stopping; i += 1) {
      try {
        await init();
        return;
      } catch (err) {
        metrics.set('secureaccess_db_up', {}, 0);
        logger.warning('INICIALIZACAO_FALHOU', { category: 'application', attempt: i, error: err.message });
        await new Promise((r) => setTimeout(r, delayMs));
      }
    }
    if (!state.ready && !state.stopping) throw new Error('API não conseguiu inicializar');
  }

  function startBackground() {
    const every = (ms, fn) => {
      const t = setInterval(() => {
        if (!state.ready || state.stopping) return;
        fn().catch((err) => logger.error('TAREFA_FALHOU', { category: 'application', error: err.message }));
      }, ms);
      t.unref();
      timers.push(t);
    };
    every(30 * 1000, () => keyring.tick());
    every(15 * 1000, async () => {
      try {
        await db.ping();
        metrics.set('secureaccess_db_up', {}, 1);
      } catch {
        metrics.set('secureaccess_db_up', {}, 0);
      }
      keyring.updateGauges();
    });
  }

  async function stop() {
    state.stopping = true;
    timers.forEach(clearInterval);
    limiter.stop();
    await db.close().catch(() => {});
    logger.close();
  }

  return { deps, state, handle, handleMetrics, init, initWithRetry, startBackground, stop, logger };
}

module.exports = { createApp };
