#!/usr/bin/env bash
# Instala ou atualiza o Sentinela (monitoramento e SIEM) com Helm.
# Uso: bash scripts/deploy-sentinela.sh <domínio do Sentinela> <URL da produção> [URL da homologação] [tag]
# Ex.:  bash scripts/deploy-sentinela.sh sentinela.meudesafio.duckdns.org https://meudesafio.duckdns.org \
#            https://staging.meudesafio.duckdns.org 1.0.0
# Avisos pelo Telegram (opcional): TELEGRAM_TOKEN=... TELEGRAM_CHAT=... bash scripts/deploy-sentinela.sh ...
set -euo pipefail

HOST="${1:?informe o domínio do Sentinela (ex.: sentinela.meudesafio.duckdns.org)}"
URL_PROD="${2:?informe a URL da produção (ex.: https://meudesafio.duckdns.org)}"
URL_STAGING="${3:-}"
TAG="${4:-1.0.0}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHART="$ROOT/helm/sentinela"
NAMESPACE="${SENTINELA_NAMESPACE:-sentinela}"

args=(--set ingress.host="$HOST" --set image.tag="$TAG" --set ambientes.producao.url="$URL_PROD")
if [ -n "$URL_STAGING" ]; then
  args+=(--set ambientes.homologacao.url="$URL_STAGING")
else
  args+=(--set ambientes.homologacao.ativo=false)
fi
if [ -n "${TELEGRAM_TOKEN:-}" ]; then
  args+=(--set-string telegram.token="$TELEGRAM_TOKEN" --set-string telegram.chatId="${TELEGRAM_CHAT:?defina TELEGRAM_CHAT junto com TELEGRAM_TOKEN}")
fi

helm lint "$CHART" "${args[@]}"
helm upgrade --install sentinela "$CHART" --history-max 50 \
  --namespace "$NAMESPACE" --create-namespace \
  "${args[@]}" \
  --wait --timeout 10m \
  --description "deploy $TAG em $(date -u +%Y-%m-%dT%H:%M:%SZ)"
helm test sentinela -n "$NAMESPACE" --logs
helm history sentinela -n "$NAMESPACE"
