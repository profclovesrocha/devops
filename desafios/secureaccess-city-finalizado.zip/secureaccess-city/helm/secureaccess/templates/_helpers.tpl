{{/*
Blocos reutilizáveis do chart SecureAccess City.
*/}}

{{/* Prefixo dos recursos: o próprio nome da release (ex.: sa-prod). */}}
{{- define "secureaccess.fullname" -}}
{{- .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}

{{- define "secureaccess.componentName" -}}
{{- printf "%s-%s" (include "secureaccess.fullname" .ctx) .component | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Secret único com todos os segredos (convenção <release>-secrets). */}}
{{- define "secureaccess.secretName" -}}
{{- .Values.global.existingSecret | default (printf "%s-secrets" .Release.Name) -}}
{{- end -}}

{{- define "secureaccess.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: secureaccess
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: secureaccess-city
secureaccess.city/environment: {{ .Values.global.environment }}
{{- end -}}

{{/* Uso: include "secureaccess.selectorLabels" (dict "ctx" $ "component" "api") */}}
{{- define "secureaccess.selectorLabels" -}}
app.kubernetes.io/name: secureaccess
app.kubernetes.io/instance: {{ .ctx.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{- define "secureaccess.componentLabels" -}}
{{ include "secureaccess.labels" .ctx }}
app.kubernetes.io/component: {{ .component }}
{{- end -}}

{{/* Imagem completa: <registro>/<repositório>:<tag> */}}
{{- define "secureaccess.image" -}}
{{- $registry := .ctx.Values.image.registry -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" (trimSuffix "/" $registry) .repository (toString .ctx.Values.image.tag) -}}
{{- else -}}
{{- printf "%s:%s" .repository (toString .ctx.Values.image.tag) -}}
{{- end -}}
{{- end -}}

{{- define "secureaccess.dbHost" -}}
{{- if .Values.mysql.enabled -}}
{{- printf "%s-mysql" .Release.Name -}}
{{- else -}}
{{- required "externalDatabase.host é obrigatório quando mysql.enabled=false" .Values.externalDatabase.host -}}
{{- end -}}
{{- end -}}

{{/* Endurecimento padrão do pod: sem root, sem token da API do Kubernetes. */}}
{{- define "secureaccess.podSecurity" -}}
automountServiceAccountToken: false
securityContext:
  runAsNonRoot: true
  runAsUser: {{ .uid }}
  runAsGroup: {{ .uid }}
  fsGroup: {{ .uid }}
  seccompProfile:
    type: RuntimeDefault
{{- end -}}

{{- define "secureaccess.containerSecurity" -}}
securityContext:
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop: ["ALL"]
{{- end -}}

{{- define "secureaccess.imagePullSecrets" -}}
{{- with .Values.image.pullSecrets }}
imagePullSecrets:
  {{- range . }}
  - name: {{ . }}
  {{- end }}
{{- end }}
{{- end -}}
