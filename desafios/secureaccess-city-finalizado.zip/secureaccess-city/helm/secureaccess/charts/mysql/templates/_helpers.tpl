{{/* Nome dos recursos do banco: <release>-mysql */}}
{{- define "mysql.fullname" -}}
{{- printf "%s-mysql" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/* Secret compartilhado com o chart principal (convenção <release>-secrets). */}}
{{- define "mysql.secretName" -}}
{{- $global := .Values.global | default dict -}}
{{- .Values.auth.existingSecret | default (get $global "existingSecret") | default (printf "%s-secrets" .Release.Name) -}}
{{- end -}}

{{- define "mysql.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
app.kubernetes.io/name: secureaccess
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: database
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: secureaccess-city
{{- end -}}

{{- define "mysql.selectorLabels" -}}
app.kubernetes.io/name: secureaccess
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: database
{{- end -}}
