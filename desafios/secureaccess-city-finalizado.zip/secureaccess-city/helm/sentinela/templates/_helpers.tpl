{{/* Blocos reutilizáveis do chart Sentinela. */}}

{{- define "sentinela.fullname" -}}
{{- .Release.Name | trunc 50 | trimSuffix "-" -}}
{{- end -}}

{{- define "sentinela.secretName" -}}
{{- .Values.existingSecret | default (printf "%s-segredos" (include "sentinela.fullname" .)) -}}
{{- end -}}

{{- define "sentinela.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: sentinela
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: secureaccess-city
{{- end -}}

{{- define "sentinela.selectorLabels" -}}
app.kubernetes.io/name: sentinela
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: sentinela
{{- end -}}

{{- define "sentinela.image" -}}
{{- if .Values.image.registry -}}
{{- printf "%s/%s:%s" (trimSuffix "/" .Values.image.registry) .Values.image.repository (toString .Values.image.tag) -}}
{{- else -}}
{{- printf "%s:%s" .Values.image.repository (toString .Values.image.tag) -}}
{{- end -}}
{{- end -}}
